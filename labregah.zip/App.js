import React,{useState, useEffect, Component} from 'react';
import * as Font from 'expo-font';
import {View, StyleSheet, Alert, ActivityIndicator, I18nManager as RNI18nManager} from 'react-native';
import AppContainer from './navigation';
import * as Updates from 'expo-updates';
import i18n from './services/i18n';
import {
  SafeAreaView,
  SafeAreaProvider,
  SafeAreaInsetsContext,
  useSafeAreaInsets,
  initialWindowMetrics,
} from 'react-native-safe-area-context';

import {createStore, combineReducers, applyMiddleware} from 'redux';
import homeReducer from './store/reducers/homeReducer';
import racingVideosReducer from './store/reducers/racingVideosReducer';
import racingResultsReducer from './store/reducers/racingResultsReducer';
import racingDatesReducer from './store/reducers/racingDatesReducer';
import {Provider} from 'react-redux';
import ReduxThunk from 'redux-thunk';
import Toast from "react-native-toast-message";
import Amplify from "@aws-amplify/core";
import config from "./aws-exports";
import {registerForPushNotificationsAsync} from "./utils/Notifications";
import { Colors } from './constants';
Amplify.configure(config);

const rootReducer = combineReducers({
  home: homeReducer,
  racingVideos: racingVideosReducer,
  racingResults: racingResultsReducer,
  racingDates: racingDatesReducer
});

const store = createStore(rootReducer, applyMiddleware(ReduxThunk));

export default class App extends Component {
  state = { isI18nInitialized: false }
  componentDidMount() {
    Font.loadAsync({
      'open-sans': require('./assets/fonts/OpenSans-Regular.ttf'),
      'open-sans-bold': require('./assets/fonts/OpenSans-Bold.ttf'), 
      'cairo-bold': require('./assets/fonts/Cairo-Bold.ttf'),  
      'cairo-black': require('./assets/fonts/Cairo-ExtraLight.ttf'),
      'cairo-light': require('./assets/fonts/Cairo-Light.ttf'),
      'cairo-extralight': require('./assets/fonts/Cairo-ExtraLight.ttf'),
      'cairo-regular': require('./assets/fonts/Cairo-Regular.ttf'),
      'cairo-semibold': require('./assets/fonts/Cairo-SemiBold.ttf')
    }).then(
     
      i18n.init())
          .then(() => {
              const RNDir = RNI18nManager.isRTL ? 'RTL' : 'LTR';
              // RN doesn't always correctly identify native
              // locale direction, so we force it here.
              if (i18n.dir !== RNDir) {
                  const isLocaleRTL = i18n.dir === 'RTL';
                  RNI18nManager.forceRTL(isLocaleRTL);
                  // RN won't set the layout direction if we
                  // don't restart the app's JavaScript.
                  Updates.reloadAsync();
              }
              this.setState({ isI18nInitialized: true });
          })
          .catch((error) => console.warn(error));

         
            registerForPushNotificationsAsync();
  }
  render() {
      if (this.state.isI18nInitialized) {
          return <Provider store={store}><><AppContainer /><Toast ref={(ref) => Toast.setRef(ref)} /></></Provider> ;
      }
      return (
          <View style={styles.loadingScreen}>
              <ActivityIndicator color={Colors.primaryColor} />
          </View>
      );
  }
}
const styles = StyleSheet.create({
  loadingScreen: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
  }
});

// export default function App() {
//   const [fontLoaded, setFontLoaded] = useState(false);
//   const [isI18nInitialized, setIsI18nInitialized] = useState(false);
//   const [isI18nInitializationTriggered, setIsI18nInitializationTriggered] = useState(false);

//   if (!fontLoaded){
//     return (
//       <AppLoading startAsync={fetchFonts} onFinish={()=>{setFontLoaded(true);setIsI18nInitialized(true);}    
//     }/>
//     );

//     return (
//       <AppNavigator/>
//     );    
//   }

  
  // useEffect(() => {
  //   if (!isI18nInitializationTriggered){
  //     console.trace('start i18n initialization');
  //     setIsI18nInitializationTriggered(true);

  //   i18n.init()
  //   .then(() => {
  //       const RNDir = RNI18nManager.isRTL ? 'RTL' : 'LTR';
  //       // RN doesn't always correctly identify native
  //       // locale direction, so we force it here.
  //       if (i18n.dir !== RNDir) {
  //           const isLocaleRTL = i18n.dir === 'RTL';
  //           RNI18nManager.forceRTL(isLocaleRTL);
  //           // RN won't set the layout direction if we
  //           // don't restart the app's JavaScript.
  //           Updates.reloadFromCache();
  //       }
  //      // this.setState({ isI18nInitialized: true });
  //      setIsI18nInitialized(true);
  //   })
  //   .catch((error) => console.warn(error));
  // }
  // });

  // if (isI18nInitialized) {
  //   return (
  //     <AppNavigator/>
  //   );
  // }

//   return (
//     <View style={styles.loadingScreen}>
//         <ActivityIndicator />
//     </View>
// );
// }

// const styles = StyleSheet.create({
//   loadingScreen: {
//     flex: 1,
//     alignItems: 'center',
//     justifyContent: 'center',
// },  
//   container: {

//   },
// });
