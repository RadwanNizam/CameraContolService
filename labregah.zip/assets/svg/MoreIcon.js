import * as React from "react"
import Svg, { Defs, Path, Use } from "react-native-svg"

function MoreIcon(props) {
  return (
    <Svg
      width={18}
      height={4}
      viewBox="0 0 18 4"
      {...props}
    >
      <Defs>
        <Path
          id="prefix__a"
          d="M9 0a2 2 0 11.001 3.999A2 2 0 019 0zm7 0a2 2 0 11.001 3.999A2 2 0 0116 0zM2 0a2 2 0 11.001 3.999A2 2 0 012 0z"
        />
      </Defs>
      <Use fill={props.color} xlinkHref="#prefix__a" fillRule="evenodd" />
    </Svg>
  )
}

export default MoreIcon
