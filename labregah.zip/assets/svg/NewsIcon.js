import * as React from "react"
import Svg, { G, Path, Rect } from "react-native-svg"

function NewsIcon(props) {
  return (
    <Svg
      width={21}
      height={21}
      viewBox="0 0 21 21"
      {...props}
    >
      <G transform="translate(1 1)" fill="none" fillRule="evenodd">
        <Path
          fill={props.color}
          fillRule="nonzero"
          d="M9.988 4.552H3.433a.715.715 0 00-.715.715v5.363c0 .395.32.716.715.716h6.555c.395 0 .715-.32.715-.716V5.267a.715.715 0 00-.715-.715zm-.715 5.363H4.148V5.982h5.125v3.933z"
        />
        <Rect width={19} height={19} stroke={props.color} strokeWidth={2} rx={3} />
        <Path
          fill={props.color}
          fillRule="nonzero"
          d="M16.067 4.552h-3.338a.715.715 0 100 1.43h3.338a.715.715 0 100-1.43zm0 2.86h-3.338a.715.715 0 100 1.431h3.338a.715.715 0 000-1.431zm0 2.861h-3.338a.715.715 0 100 1.43h3.338a.715.715 0 100-1.43zm0 2.86H3.433a.715.715 0 000 1.431h12.634a.715.715 0 100-1.431z"
        />
      </G>
    </Svg>
  )
}

export default NewsIcon
