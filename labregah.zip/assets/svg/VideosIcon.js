import * as React from "react"
import Svg, { G, Rect, Path } from "react-native-svg"

function VideosIcon(props) {
  return (
    <Svg
      width={21}
      height={21}
      viewBox="0 0 21 21"
      {...props}
    >
      <G
        transform="translate(1 1)"
        stroke={props.color}
        fill="none"
        fillRule="evenodd"
      >
        <Rect width={19} height={19} strokeWidth={2} rx={3} />
        <Path
          fill={props.color}
          fillRule="nonzero"
          strokeWidth={1.5}
          d="M6.801 5.75c.01 0 .018.003.026.008h0l6.4 4c.014.009.023.025.023.042s-.009.033-.023.042h0L7.054 13.7a2.13 2.13 0 01-.148-.026l6.2-3.874L6.85 5.89v7.772a1.391 1.391 0 01-.1-.028h0V5.8c.02-.04.035-.05.051-.05z"
        />
      </G>
    </Svg>
  )
}

export default VideosIcon
