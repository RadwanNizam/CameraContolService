export { default as VideosIcon } from "./VideosIcon";
export { default as NewsIcon } from "./NewsIcon";
export { default as MoreIcon } from "./MoreIcon";
export { default as CalendarIcon } from "./CalendarIcon";
export { default as HomeIcon } from "./HomeIcon";