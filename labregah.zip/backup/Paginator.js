import React from 'react';
import { FlatList, View, Animated, Platform, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';




const IOS = Platform.OS === 'ios';

const VIEWABILITY_CONFIG = {
  viewAreaCoveragePercentThreshold: 50,
};
const ORANGE = 'rgb(237,172,113)';
const GRAY = 'rgba(0,0,0,0.3)';


const Paginator = ({
  data,
  renderItem,
  keyExtractor,
  contentContainerStyle,
  itemWidth,
}) => {
  const scrollValue = React.useRef(new Animated.Value(0));

  let visibleElement = 0;
  const flatlist = React.useRef();

  const getItemLayout = (data, index) => ({
    length: itemWidth,
    offset: itemWidth * index,
    index,
  });

  const onViewableItemsChanged = (info) => {
    const { index = 0 } = info.viewableItems[0];
    visibleElement = index;
  };

  const onScrollEndDrag = (e) => {
    const speed = e.nativeEvent.velocity.x;
    let minSpeed = 0.2;

    if (IOS) {
      if (speed > minSpeed && visibleElement < data.length - 1) {
        visibleElement += 1;
      }
      if (speed < (-1 * minSpeed) && visibleElement > 0) {
        visibleElement -= 1;
      }
    }
    //  needs to be tested
    if (!IOS) {
      if (speed < (-1 * minSpeed) && visibleElement < data.length - 1) {
        visibleElement += 1;
      }
      if (speed > (minSpeed) && visibleElement > 0) {
        visibleElement -= 1;
      }
    }

    flatlist.current.scrollToIndex({ index: visibleElement, animated: true, viewPosition: 0.5 });
  };

  
  return (
      <FlatList
        // onScroll={Animated.event([{
        //   nativeEvent: { contentOffset: { x: scrollValue.current } },
        // }])}
        data={data}
        renderItem={renderItem}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={contentContainerStyle}
        keyExtractor={keyExtractor}
        ref={flatlist}
        getItemLayout={getItemLayout}
        viewabilityConfig={VIEWABILITY_CONFIG}
        //onViewableItemsChanged={onViewableItemsChanged}
        //onScrollEndDrag={onScrollEndDrag}
        disableIntervalMomentum = {true}
        snapToOffsets = {[0, itemWidth - ((itemWidth)*12.5/100), (itemWidth*2) - ((itemWidth)*12.5/100), (itemWidth*3)-((itemWidth)*12.5/100)]}
        disableScrollViewPanResponder = {true}
        decelerationRate={0.985}
        snapToEnd={false}
        snapToStart={false}
        fadingEdgeLength={2}
      />    
  );
};

Paginator.propTypes = {
  data: PropTypes.arrayOf(PropTypes.shape({})),
  renderItem: PropTypes.func,
  keyExtractor: PropTypes.func,
  contentContainerStyle: PropTypes.shape({}),
  itemWidth: PropTypes.number,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  animationContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    marginBottom: 8,
  },

  indicator: {
    height: 7,
    width: 7,
    borderRadius: 2,
  },
});

export default Paginator;