import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, ScrollView, Button } from 'react-native';

const SlowAutoScroller = props => {
  const scrollRef = useRef();
  const scrollAnimation = useRef(new Animated.Value(0));
  const [contentHeight, setContentHeight] = useState(0);

  useEffect(() => {
    scrollAnimation.current.addListener((animation) => {
      scrollRef.current &&
        scrollRef.current.scrollTo({
          y: animation.value,
          animated: false,
        })
    })

    if (contentHeight) {
      Animated.timing(scrollAnimation.current, {
        toValue: contentHeight,
        duration: contentHeight * 100,
        useNativeDriver: true,
        easing: Easing.linear,
      }).start()
    }
    return () => scrollAnimation.current.removeAllListeners()
  }, [contentHeight])

  return (
    <Animated.ScrollView
      ref={scrollRef}
      onContentSizeChange={(width, height) => {
        setContentHeight(height)
      }}
      onScrollBeginDrag={() => scrollAnimation.current.stopAnimation()}
    >
      <Button title='News'/>
      <Button title='Videos'/>
      <Button title='Photos'/>
    </Animated.ScrollView>
  )
}

export default SlowAutoScroller;

// https://reactnative.dev/docs/animations