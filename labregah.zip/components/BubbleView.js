import React from "react";
import { View, StyleSheet, FlatList } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";

const styles = StyleSheet.create({
  container: {},
  sectionTitle: {
    color: Colors.gray,
    fontSize: Fonts.size.normal,
    marginLeft: Layout.margin.content,
    marginTop: Layout.margin.small,
    marginBottom: Layout.margin.tiny,
  },
  listContainer: {
    paddingHorizontal: Layout.padding.content,
  },
  item: {
    backgroundColor: Colors.primaryColor,
    borderWidth: 1,
    borderColor: Colors.primaryColor,
    marginHorizontal: Layout.margin.tiny,
  },
  unselectedItem: {
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.lightGray,
  },
});

function BubbleView(props) {
  const keyExtractor = (item) => item;
  const renderItem = ({ item }) => {
    const isSelected = props.selected == item;
    const onPress = () => {
      props.onSelect(item);
    };
    return (
      <StyledText
        rounded
        color={isSelected ? Colors.white : Colors.gray}
        containerStyle={[styles.item, !isSelected && styles.unselectedItem]}
        touchable
        onPress={onPress}
        children={item}
      />
    );
  };
  return (
    <View style={styles.container}>
      <StyledText bold style={styles.sectionTitle} children={props.title} />
      <View style={{alignItems: 'flex-start'}}>
        <FlatList
          horizontal
          contentContainerStyle={styles.listContainer}
          showsHorizontalScrollIndicator={false}
          data={props.data}
          keyExtractor={keyExtractor}
          renderItem={renderItem}
        />
      </View>
    </View>
  );
}

export default BubbleView;

// PropTypes.oneOf([true, false, undefined])
BubbleView.propTypes = {
  data: PropTypes.arrayOf(PropTypes.string),
  selected: PropTypes.string,
  onSelect: PropTypes.func,
  title: PropTypes.string,
};

BubbleView.defaultProps = {};
