import React from 'react'
import { View, Text, StyleSheet, Button } from 'react-native'
import Colors from '../constants/Colors';

export const ErrorHandler = (props) => {
  return (
    <View style={styles.centered}>
      <Text>An error occurred!</Text>
      <Button
        title="Try again"        
        onPress={props.onPress}
        color={Colors.primary}
      />
      <Text>{props.error}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' }
});

export default ErrorHandler; 
