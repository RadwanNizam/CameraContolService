import React from 'react' 
import { View, Text, StyleSheet, Image, Title } from 'react-native' 
import { TouchableOpacity } from 'react-native-gesture-handler';
import Colors from '../constants/Colors';
import moment from 'moment';



  
export const GenericPost = (props) => { 
  const {post, posts} = props;
  return ( 
 
     <View style={styles.paper}> 
    
      <View style={styles.paperContainer}>
        <Image source={{ uri: post.featuredImgUrl }} style={styles.featuredImage} />
            <Text numberOfLines={2} style={styles.title}>{post.title}</Text>
            <View style={{flex:1, flexDirection:"row", paddingTop:2}}>
              <Text style={{...styles.date, paddingEnd:30}}>{moment(post.date).format("MMM DD - YYYY")}</Text>
              <Text style={styles.date}>عدد المشاهدات 200</Text>
            </View>
        </View>
 
    </View>

   ); 
 } ;

 const styles = StyleSheet.create({ 
    paper: { 
      borderRadius: 20,
      borderStyle: "solid",
      // borderWidth: 1,
      // borderColor: Colors.forthColor,
      paddingTop: 20
     },paperContainer:{
        display:"flex",
        flexDirection:"column",
     }, 
     featuredImage:{
        borderRadius: 20,
        backgroundColor: Colors.secondaryColor,
        width:'100%',
        aspectRatio:2/1
     },  date:{
        fontFamily: "cairo-regular",
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        letterSpacing: 0,
        color: Colors.fontColor4,
        paddingTop: 5,
        textAlign:"left",
        paddingStart: 5,
        paddingBottom: 5
      },title:{
        fontFamily: "cairo-regular",
        fontSize: 16,
        fontWeight: "normal",
        fontStyle: "normal",
        letterSpacing: 0,
        // textAlign: "right",
        color: Colors.fontColor2,
        textAlign: "left",
        paddingStart:5,
        paddingTop:5
      }
 }); 
    
 

 export default GenericPost; 
