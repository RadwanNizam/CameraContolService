import React from 'react';
import { View, FlatList, StyleSheet, Image, Text} from 'react-native';
import Title from '../components/Title';

const ItemsList = props => {
    const renderItem = ( {item, navigation}) => {
	
      const formattedDate = Intl.DateTimeFormat('en-US',{
        year: 'numeric',
        month: 'short',
        day: '2-digit' }).format(item.date);      
        return <View style={styles.container}>          
          <View style={styles.imageContainer}><Image source={{ uri: item.imageUrl }} style={styles.image} /></View>
          <View style={styles.titleContainer}>
            <Title fontWeight={4} numberOfLines={2} style={styles.title}>{item.title}</Title>
            <Title fontWeight={1} numberOfLines={1} style={styles.title}>{formattedDate}</Title>
          </View>
        </View>
      };

    return (
            <FlatList 
                data={props.data} 
                renderItem={(item) => renderItem(item, props.navigation)} 
                numColumns={1}
                keyExtractor={(item, index) => item.id} 
                scrollEnabled={props.scrollEnabled}
                showsVerticalScrollIndicator = {false}
            /> 
    );   
};

const styles = StyleSheet.create({
    list:{
        flex: 1,
        borderColor: 'red',
        borderWidth: 3
    }, 
    container:{
        flex:1,
        flexDirection: 'row',
        paddingBottom: 15
    },
    titleContainer:{
      width: '60%',
      flex: 1,
      // borderColor: 'red',
      // borderWidth:1,
      justifyContent: 'flex-start',
      alignItems: 'flex-start',
      paddingStart: 10
    },
    title:{

      fontSize: 14,
      paddingTop:0,
      lineHeight: 20

    },
    imageContainer:{
      width: '40%',
        // paddingStart: 10,
        // paddingEnd: 10,
        //paddingTop: 10
    },
    image: {
     
      aspectRatio: 16 / 9,
      
    //   borderRadius: 10,
    //   overflow: "hidden"
    }
});

export default ItemsList; 
