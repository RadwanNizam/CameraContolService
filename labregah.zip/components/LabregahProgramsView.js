import React from "react";
import { View, StyleSheet, Image, TouchableOpacity, ViewPropTypes } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import { useSelector } from "react-redux";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: Layout.padding.content,
    flexDirection: "row",
    height: Layout.window.height * 0.25,
    justifyContent: "space-between",
  },
  imageContainer: {
    ...Styles.shadow.small,
    borderRadius: Layout.radius.xxLarge,
  },
  rightContainer: {
    flex: 0.36,
    marginRight: Layout.margin.small,
    justifyContent: "space-between",
  },
  image: {
    flex: 1,
    borderRadius: Layout.radius.xxLarge,
  },
  topRight: {
    borderTopLeftRadius: Layout.radius.xxxLarge,
  },
  bottomRight: {
    borderBottomLeftRadius: Layout.radius.xxxLarge,
  },
  left: {
    borderTopRightRadius: Layout.radius.xxxLarge,
    borderBottomRightRadius: Layout.radius.xxxLarge,
  },
});

const Program = ({ size, style, onPress, uri }) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[{ flex: size }, styles.imageContainer, style]}
    >
      <Image style={[styles.image, style]} source={{ uri }} />
    </TouchableOpacity>
  );
};
function LabregahProgramsView(props) {
  const latestPrograms = props.latestPrograms;
  const onPress = (index) => () => props.onProgramPress(latestPrograms[index]);
  return (
    <View style={[styles.container, props.style]}>
      {/* Right */}
      <View style={styles.rightContainer}>
        {/* Top Right */}
        <Program
          size={0.57}
          onPress={onPress(1)}
          style={styles.topRight}
          uri={latestPrograms[1].featuredImgUrl}
        />
        {/* Bottom Right */}
        <Program
          size={0.39}
          onPress={onPress(2)}
          style={styles.bottomRight}
          uri={latestPrograms[2].featuredImgUrl}
        />
      </View>
      {/* Left */}
      <Program
        size={0.63}
        onPress={onPress(0)}
        style={styles.left}
        uri={latestPrograms[0].featuredImgUrl}
      />
    </View>
  );
}

export default LabregahProgramsView;
// PropTypes.oneOf([true, false, undefined])
LabregahProgramsView.propTypes = {
  onProgramPress: PropTypes.func,
  style: ViewPropTypes.style
};

LabregahProgramsView.defaultProps = {
  onProgramPress: (program) => {},
};
