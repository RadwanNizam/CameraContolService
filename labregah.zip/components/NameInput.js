import React, { useState } from "react";
import {
  View,
  StyleSheet,
  ViewPropTypes,
  TextInput,
  I18nManager,
  Text,
} from "react-native";
import PropTypes from "prop-types";
import { Colors, Fonts, Layout } from "../constants";
import StyledText from "./StyledText";

const styles = StyleSheet.create({
  container: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  input: {
    width: "48%",
    borderWidth: 1,
    borderColor: Colors.white,
    paddingVertical: Layout.padding.medium,
    paddingHorizontal: Layout.padding.normal,
    fontSize: Fonts.size.normal,
    fontFamily: Fonts.type.regular,
    color: Colors.white,
    borderRadius: Layout.radius.round,
    textAlign: I18nManager.isRTL ? "right" : "auto",
  },
  error: {
    color: Colors.error,
    margin: Layout.margin.small,
    marginTop: 0,
  },
});

function NameInput(props) {
  return (
    <View style={[props.containerStyle, { width: "100%" }]}>
      <StyledText style={styles.error} children={props.error} />

      <View style={[styles.container, props.style]}>
        <TextInput
          style={[styles.input, props.error && { borderColor: Colors.error }]}
          placeholder={"الاسم الاول"}
          textContentType={"givenName"}
          value={props.firstName}
          onChangeText={props.setFirstName}
          placeholderTextColor={"rgba(255, 255, 255, 0.7)"}
        />
        <TextInput
          style={[styles.input, props.error && { borderColor: Colors.error }]}
          placeholder={"العائلة"}
          textContentType={"familyName"}
          value={props.lastName}
          onChangeText={props.setLastName}
          placeholderTextColor={"rgba(255, 255, 255, 0.7)"}
        />
      </View>
    </View>
  );
}

export default NameInput;

// PropTypes.oneOf([true, false, undefined])
NameInput.propTypes = {
  style: ViewPropTypes.style,
  containerStyle: ViewPropTypes.style,
  firstName: PropTypes.string,
  setFirstName: PropTypes.func,
  lastName: PropTypes.string,
  setLastName: PropTypes.func,
  error: PropTypes.string,
};

NameInput.defaultProps = {
  style: {},
  containerStyle: {},
  firstName: "",
  setFirstName: () => {},
  lastName: "",
  setLastName: () => {},
  error: "",
};
