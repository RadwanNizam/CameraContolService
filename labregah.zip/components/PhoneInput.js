import React, { useState } from "react";
import {
  View,
  StyleSheet,
  ViewPropTypes,
  TextInput,
  I18nManager,
  Text,
} from "react-native";
import PropTypes from "prop-types";
import CountryPicker, {
  DARK_THEME,
  DEFAULT_THEME,
} from "react-native-country-picker-modal";
import { Colors, Fonts, Layout } from "../constants";
import StyledText from "./StyledText";

const styles = StyleSheet.create({
  container: {
    width: "100%",
    flexDirection: "row",
    borderRadius: 30,
    flexDirection: Layout.leftDirection,
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.9)",
  },
  buttonContainer: {
    alignItems: "center",
    justifyContent: "center",
    padding: 12,
    [`border${I18nManager.isRTL ? "Left" : "Right"}Width`]: 0.5,
    borderColor: "rgba(255, 255, 255, 0.9)",
    flexDirection: I18nManager.isRTL ? "row-reverse" : "row",
  },
  input: {
    flex: 1,
    letterSpacing: 1,
    paddingHorizontal: Layout.padding.normal,
    fontSize: Fonts.size.normal,
    color: Colors.white,
  },
  error: {
    color: Colors.error,
    margin: Layout.margin.small,
    marginTop: 0,
  },
});

function PhoneInput(props) {
  const { phone, onChange } = props;
  const [theme, setTheme] = useState(DARK_THEME);
  const onCountrySelect = (country) => {
    const { callingCode, cca2 } = country;
    onChange({
      ...phone,
      callingCode: callingCode[0],
      cca2,
    });
  };

  const onChangeText = (number) => {
    onChange({
      ...phone,
      number,
    });
  };
  const onOpen = () => setTheme(DEFAULT_THEME);
  const onClose = () => setTheme(DARK_THEME);
  return (
    <View style={props.containerStyle}>
      <StyledText style={styles.error} children={props.error} />

      <View
        style={[
          styles.container,
          props.style,
          props.error && { borderColor: Colors.error },
        ]}
      >
        <CountryPicker
          onSelect={onCountrySelect}
          theme={theme}
          visible={false}
          onOpen={onOpen}
          onClose={onClose}
          withEmoji
          withFlag
          withFilter
          withCallingCode
          withCallingCodeButton
          countryCode={phone.cca2}
          withAlphaFilter={!I18nManager.isRTL}
          containerButtonStyle={styles.buttonContainer}
        />
        <TextInput
          style={styles.input}
          placeholder={"66088429"}
          keyboardType={"number-pad"}
          textContentType={"telephoneNumber"}
          autoCompleteType={"tel"}
          value={phone.number}
          onChangeText={onChangeText}
          placeholderTextColor={"rgba(255, 255, 255, 0.7)"}
        />
      </View>
    </View>
  );
}

export default PhoneInput;

// PropTypes.oneOf([true, false, undefined])
PhoneInput.propTypes = {
  style: ViewPropTypes.style,
  containerStyle: ViewPropTypes.style,
  onChange: PropTypes.func,
  phone: PropTypes.object,
  error: PropTypes.string,
};

PhoneInput.defaultProps = {
  style: {},
  containerStyle: {},
  onChange: () => {},
  phone: {
    callingCode: "974",
    cca2: "QA",
    number: "",
  },
  error: "",
};
