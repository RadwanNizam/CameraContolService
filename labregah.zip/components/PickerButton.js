import React, { useState } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ViewPropTypes,
} from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";
import Modal from "react-native-modal";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { t } from "../services/i18n";
import { ActivityIndicator } from "react-native";

const styles = StyleSheet.create({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: Colors.white,
    borderTopLeftRadius: Layout.radius.xxxLarge,
    borderTopRightRadius: Layout.radius.xxxLarge,
    paddingVertical: Layout.padding.normal,
    maxHeight: "60%",
  },
  itemContainer: {
    ...Styles.shadow.tiny,
    backgroundColor: Colors.white,
    paddingVertical: Layout.padding.tiny,
    paddingHorizontal: Layout.padding.normal,
    marginVertical: Layout.margin.small,
    borderRadius: Layout.radius.large,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  buttonStyle: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Layout.padding.normal,
    paddingVertical: Layout.padding.tiny,
    borderWidth: 1,
    borderRadius: Layout.radius.round,
    borderColor: Colors.white,
  },
});

function PickerButton(props) {
  const [visible, setVisible] = useState(false);
  const insets = useSafeAreaInsets();
  const open = () => setVisible(true);
  const close = () => setVisible(false);

  const keyExtractor = (item) => item.id;
  const renderItem = ({ item }) => {
    const onPress = () => {
      props.onSelect(item);
      close();
    };
    return (
      <PickerItem
        item={item}
        isSelected={item.id == props.selected}
        onPress={onPress}
      />
    );
  };

  return (
    <View style={{ flex: 1 }}>
      <TouchableOpacity
        disabled={props.disabled}
        onPress={open}
        style={[styles.buttonStyle, props.style]}
      >
        <Ionicons
          name="ios-arrow-down"
          size={Fonts.size.small}
          color={Colors.white}
        />
        <StyledText
          center
          style={{ flex: 1, marginLeft: Layout.margin.small }}
          children={props.value || props.placehoolder}
          numberOfLines={1}
          ellipsizeMode={"tail"}
        />
      </TouchableOpacity>

      <Modal
        isVisible={visible}
        style={styles.modal}
        onSwipeComplete={close}
        onBackdropPress={close}
      >
        <View
          style={[
            styles.container,
            { paddingBottom: insets.bottom + Layout.padding.xLarge },
          ]}
        >
          <StyledText
            bold
            center
            color={Colors.gray}
            children={props.title}
            size={Fonts.size.large}
          />
          <View>
            <FlatList
              keyExtractor={keyExtractor}
              contentContainerStyle={{
                paddingHorizontal: Layout.padding.content,
                paddingBottom: insets.bottom,
              }}
              ListEmptyComponent={
                props.isLoading ? (
                  <ActivityIndicator color={Colors.primaryColor} />
                ) : (
                  <StyledText
                    bold
                    color={Colors.gray}
                    children={t("common:empty")}
                  />
                )
              }
              data={props.data}
              renderItem={renderItem}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const PickerItem = (props) => {
  const { item, isSelected, onPress } = props;

  return (
    <TouchableOpacity onPress={onPress} style={styles.itemContainer}>
      <StyledText
        color={isSelected ? Colors.primaryColor : Colors.gray}
        size={Fonts.size.normal}
        children={item.name}
      />
      {isSelected && (
        <Ionicons
          name="md-checkmark"
          size={Fonts.size.normal}
          color={Colors.primaryColor}
        />
      )}
    </TouchableOpacity>
  );
};

export default PickerButton;
// PropTypes.oneOf([true, false, undefined])
PickerButton.propTypes = {
  disabled: PropTypes.oneOf([true, false, undefined]),
  isLoading: PropTypes.oneOf([true, false, undefined]),
  value: PropTypes.string,
  title: PropTypes.string,
  placehoolder: PropTypes.string,
  data: PropTypes.array,
  onSelect: PropTypes.func,
  selected: PropTypes.string,
  style: ViewPropTypes.style,
};

PickerButton.defaultProps = {
  disabled: false,
  data: [],
  onSelect: (item) => {},
  value: "",
  title: "اختر",
  placehoolder: "اختر",
  style: {},
};
