import React, { useMemo } from "react";
import { View, StyleSheet, TouchableOpacity } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";

const styles = StyleSheet.create({
  container: {
    ...Styles.shadow.tiny,
    flex: 1,
    flexDirection: "row",
    backgroundColor: Colors.white,
    margin: Layout.margin.small,
    padding: Layout.padding.normal,
    borderRadius: Layout.radius.xxLarge,
  },
  line: {
    backgroundColor: Colors.lightGray,
    width: 1,
    height: "100%",
    marginHorizontal: Layout.margin.normal,
  },
});

function Race(props) {
  const country = useMemo(
    () => props.countries.find((country) => country.id == props.country[0]),
    [props.countries]
  );
  const season = useMemo(
    () => props.seasons.find((season) => season.id == props.season[0]),
    [props.seasons]
  );
  return (
    <TouchableOpacity onPress={props.onPress} style={styles.container}>
      <View style={{ justifyContent: "center" }}>
        <StyledText center bold color={Colors.gray} children={season?.name} />
        <StyledText center bold color={Colors.gray} children={country?.name} />
      </View>
      <View style={styles.line} />
      <View style={{ flex: 1 }}>
        <StyledText
          bold
          color={Colors.primaryColor}
          size={Fonts.size.medium}
          children={props.title}
        />
        <StyledText
          color={Colors.gray}
          size={Fonts.size.medium}
          children={props.to != null ? props.to + " - " + props.from : ''}
        />
      </View>
    </TouchableOpacity>
  );
}

export default Race;
// PropTypes.oneOf([true, false, undefined])
Race.propTypes = {};

Race.defaultProps = {};
