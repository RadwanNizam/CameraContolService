import React from "react";
import { View, StyleSheet, TouchableOpacity, Image } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";
import { Ionicons } from "@expo/vector-icons";
import { t } from "../services/i18n";
import { onlyUpdateForKeys } from "recompose";

const styles = StyleSheet.create({
  container: {
    ...Styles.shadow.tiny,
    flex: 1,
    backgroundColor: Colors.white,
    margin: Layout.margin.small,
    padding: Layout.padding.normal,
    borderRadius: Layout.radius.xxLarge,
  },
  headerContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    paddingBottom: Layout.padding.small,
  },
  thumbContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    overflow: "hidden",
  },
  thumb: {
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  thumbOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    justifyContent: "center",
    alignItems: "center",
  },
  titleContainer: {
    flex: 1,
    paddingHorizontal: Layout.padding.normal,
  },
  title: {
    color: Colors.primaryColor,
    fontSize: Fonts.size.medium,
    width: "100%",
  },
  vLine: {
    backgroundColor: Colors.lightGray,
    width: 1,
    height: "100%",
  },
  hLine: {
    backgroundColor: Colors.lightGray,
    height: 1,
  },
  positionContainer: { height: 36, overflow: "hidden" },
  position: {
    marginTop: -18,
    textAlign: "center",
    fontSize: 36,
    color: Colors.gray,
  },
  footerContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: Layout.padding.medium,
  },
});

function RaceResult(props) {
  const { item } = props;
  return (
    <TouchableOpacity style={styles.container}  
    onPress={
      () => props.showVideo()
    //   () => props.navigation.navigate('Video', 
    // {post: {title: item["video_title"], url: '', postURL: item.youtubeVideoId, youtubeVideoId:item.youtubeVideoId }})
    }>
     
      {/** Header Start */}
      <View style={styles.headerContainer}>
        {/** Header Image Start */}
        <View style={Styles.shadow.small}>
          <View style={styles.thumbContainer}>
            <Image
              style={styles.thumb}
              source={{ uri: item["video"].image_thumb }}
            />
            <View style={styles.thumbOverlay}>
              <Ionicons
                name="ios-play"
                size={24}
                color={"rgba(255, 255, 255, 0.8)"}
              />
            </View>
          </View>
        </View>

        {/** Header Image End */}
        {/** Header Title Start */}
        <View style={styles.titleContainer}>
          <StyledText
            bold
            style={styles.title}
            children={`${item["إسم_المطية"]}`}
          />
          {/* <StyledText
            style={{ width: "100%" }}
            color={Colors.gray}
            children={`${t("common:round")}: ${item["الشوط"]} `}
          /> */}
        </View>
        {/** Header Title End */}
        <View style={styles.vLine} />
        {/** Header Position Start */}
        <View style={{ paddingHorizontal: Layout.padding.normal }}>
          <View style={styles.positionContainer}>
            <StyledText
              bold
              style={styles.position}
              children={item["المركز"]}
            />
          </View>
          <StyledText center children={t("common:position")} color={Colors.gray} />
        </View>
        {/** Header Position End */}
      </View>
      {/** Header End */}

      <View style={styles.hLine} />
      {/** Body Start */}
      <View style={{ paddingVertical: Layout.padding.normal }}>
        <StyledText
          color={Colors.gray}
          children={`${item["المالك"]}`}
        />
        <StyledText
          color={Colors.gray}
          children={` ${item["المضمر"]}`}
        />
      </View>
      {/** Body End */}
      <View style={styles.hLine} />
      {/** Footer Start */}
      <View style={styles.footerContainer}>
        
        <StyledText
          center
          color={Colors.gray}
          children={`${item["الشوط"]}`}

        />
        <StyledText
          center
          children={`${item["category"]}`}
          color={Colors.gray}
        />

        <StyledText
          center
          children={`${item["class"]}`}
          color={Colors.gray}
        />

<StyledText
          center
          children={` ${item["التوقيت"]}`}
          color={ Colors.primaryColor}
        />
      </View>
      {/** Footer End */}
    </TouchableOpacity>
  );
}

export default onlyUpdateForKeys(["item"])(RaceResult);
// PropTypes.oneOf([true, false, undefined])
RaceResult.propTypes = {};

RaceResult.defaultProps = {};
