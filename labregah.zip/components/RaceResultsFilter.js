import React, { useMemo, useState } from "react";
import { View, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import Modal from "react-native-modal";
import {
  SafeAreaView,
  useSafeAreaInsets,
} from "react-native-safe-area-context";
import StyledText from "./StyledText";
import TextButton from "./TextButton";
import { MaterialIcons } from "@expo/vector-icons";
import RadioButton from "./RadioButton";
import BubbleView from "./BubbleView";
import RadioView from "./RadioView";
import { t } from "../services/i18n";

const styles = StyleSheet.create({
  container: { flex: 1 },
  modal: {
    margin: 0,
    backgroundColor: Colors.white,
    justifyContent: "flex-start",
  },
  headerContainer: {
    flexDirection: "row",
    paddingHorizontal: Layout.padding.content,
    justifyContent: "space-between",
    alignItems: "center",
  },
  searchButtonContainer: {
    paddingHorizontal: Layout.margin.content,
    marginTop: Layout.margin.normal,
  },
});

function RaceResultsFilter(props) {
  const {
    visible,
    setVisible,
    fields = [],
    days = [],
    categories = [],
    periods = [],
    invitations = [],
    classes = [],
  } = props;
  const open = () => setVisible(true);
  const close = () => setVisible(false);
  const [selectedField, setSelectedField] = useState("");
  const [selectedDay, setSelectedDay] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [selectedInvitation, setSelectedInvitation] = useState("");
  const [selectedClass, setSelectedClass] = useState("");

  const onSearchPress = () => {
    props.onSearch({
      field: selectedField,
      day: selectedDay,
      category: selectedCategory,
      period: selectedPeriod,
      invitation: selectedInvitation,
      class: selectedClass,
    });
    setVisible(false);
  };

  const onClearPress = () => {
    setSelectedField("")
    setSelectedDay("")
    setSelectedCategory("")
    setSelectedPeriod("")
    setSelectedInvitation("")
    setSelectedClass("")
  }

  return (
    <Modal isVisible={visible} style={styles.modal} onSwipeComplete={close}>
      <SafeAreaView>
        <View style={styles.headerContainer}>
          <View style={{ flex: 0.25 }} />
          <StyledText
            bold
            color={Colors.gray}
            size={Fonts.size.large}
            children={t("common:filterSearch")}
          />
          <View style={{ flex: 0.25, alignItems: "flex-end" }}>
            <TouchableOpacity
              style={{ padding: Layout.padding.tiny }}
              onPress={close}
            >
              <MaterialIcons name="close" size={24} color="black" />
            </TouchableOpacity>
          </View>
        </View>
        <View>
          <BubbleView
            title={t("common:field")}
            data={fields}
            selected={selectedField}
            onSelect={setSelectedField}
          />
          <BubbleView
            title={t("common:day")}
            data={days}
            selected={selectedDay}
            onSelect={setSelectedDay}
          />
          <BubbleView
            title={t("common:category")}
            data={categories}
            selected={selectedCategory}
            onSelect={setSelectedCategory}
          />
          <BubbleView
            title={t("common:alSen")}
            data={classes}
            selected={selectedClass}
            onSelect={setSelectedClass}
          />
          <RadioView
            title={t("common:invitation")}
            data={invitations}
            selected={selectedInvitation}
            onSelect={setSelectedInvitation}
          />
          <RadioView
            title={t("common:period")}
            data={periods}
            selected={selectedPeriod}
            onSelect={setSelectedPeriod}
          />

          <View style={styles.searchButtonContainer}>
            <TextButton
              onPress={onSearchPress}
              color={Colors.primaryColor}
              textColor={Colors.white}
              children={t("common:filterSearch")}
            />
            <TextButton
              onPress={onClearPress}
              color={Colors.lightGray}
              textColor={Colors.primaryColor}
              children={t("common:clearAll")}
            />
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

export default RaceResultsFilter;
// PropTypes.oneOf([true, false, undefined])
RaceResultsFilter.propTypes = {
  visible: PropTypes.oneOf([true, false, undefined]),
  setVisible: PropTypes.func,
};

RaceResultsFilter.defaultProps = {};
