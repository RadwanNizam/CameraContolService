import React from "react";
import { View, StyleSheet, Image, TouchableOpacity, Text } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";
import { Ionicons } from "@expo/vector-icons";
import { onlyUpdateForKeys } from "recompose";
import { ninjaTableRecordToAppVideo } from "../utils/WPPostConverter";
import { useSelector } from "react-redux";

const styles = StyleSheet.create({
  container: {
    ...Styles.shadow.tiny,
    flex: 1,
    backgroundColor: Colors.white,
    margin: Layout.margin.small,
    padding: Layout.padding.normal,
    borderRadius: Layout.radius.xxLarge,
    flexDirection: "row",
    alignItems: "center",
  },
  title: {
    flex: 1,
    color: Colors.primaryColor,
    fontSize: Fonts.size.small,
    marginLeft: Layout.margin.normal,
  },
  thumbContainer: {
    width: 125,
    height: 70,
    borderRadius: Layout.radius.large,
    overflow: "hidden",
  },
  thumb: {
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  thumbOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    justifyContent: "center",
    alignItems: "center",
  },
});

function RaceVideo(props) {
  const { item } = props;
  const raceVideos = useSelector((state) => state.racingVideos.raceVideos);

  return (
    <TouchableOpacity style={styles.container} onPress={() => {
      let videos = [];
      raceVideos.map((video) => {
        videos.push(ninjaTableRecordToAppVideo(video))
      });
  
      props.navigation.navigate('Video',
        { post: ninjaTableRecordToAppVideo(item), relatedVideos: videos })
    }
    }>

      <View style={Styles.shadow.small}>
        <View style={styles.thumbContainer}>
          <Image
            style={styles.thumb}
            source={{ uri: item["video"].image_thumb }}

          />
          <View style={styles.thumbOverlay}>
            <Ionicons
              name="ios-play"
              size={24}
              color={"rgba(255, 255, 255, 0.8)"}
            />
          </View>
        </View>
      </View>
      <StyledText
        bold
        style={styles.title}
        children={item["video_title"]}
        numberOfLines={2}
      />
    </TouchableOpacity>
  );
}

export default onlyUpdateForKeys(["item"])(RaceVideo);
// PropTypes.oneOf([true, false, undefined])
RaceVideo.propTypes = {};

RaceVideo.defaultProps = {};
