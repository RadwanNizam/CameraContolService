import React from "react";
import {
  View,
  TouchableOpacity,
  StyleSheet,
  ViewPropTypes,
} from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";
import { FontAwesome5 } from "@expo/vector-icons";
const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    paddingVertical: Layout.padding.tiny,
  },
  circle: {
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: Colors.gray,
    marginRight: Layout.margin.small,
  },
  selectedCircle: {
    borderColor: Colors.primaryColor,
    backgroundColor: Colors.primaryColor,
  },
});

function RadioButton(props) {
  return (
    <TouchableOpacity
      onPress={props.onPress}
      style={[styles.container, props.style]}
    >
      <View style={[styles.circle, props.selected && styles.selectedCircle]}>
        <FontAwesome5 name="check" size={10} color={Colors.white} />
      </View>
      <StyledText
        size={Fonts.size.medium}
        color={Colors.gray}
        children={props.children}
      />
    </TouchableOpacity>
  );
}

export default RadioButton;
// PropTypes.oneOf([true, false, undefined])
RadioButton.propTypes = {
  style: ViewPropTypes.style,
  selected: PropTypes.oneOf([true, false, undefined]),
  children: PropTypes.any,
  onPress: PropTypes.func,
};

RadioButton.defaultProps = {
  selected: false,
};
