import React from "react";
import { View, StyleSheet, FlatList } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";
import RadioButton from "./RadioButton";

const styles = StyleSheet.create({
  container: {},
  sectionTitle: {
    color: Colors.gray,
    fontSize: Fonts.size.normal,
    marginLeft: Layout.margin.content,
    marginTop: Layout.margin.small,
    marginBottom: Layout.margin.tiny,
  },
  horizontalPadding: { paddingHorizontal: Layout.margin.content },
});

function RadioView(props) {
  const renderItem = (item) => {
    const isSelected = props.selected == item;
    const onPress = () => {
      props.onSelect(item);
    };
    return (
      <RadioButton
        key={item}
        selected={isSelected}
        children={item}
        onPress={onPress}
      />
    );
  };
  return (
    <View style={styles.container}>
      <StyledText bold style={styles.sectionTitle} children={props.title} />
      <View style={styles.horizontalPadding}>
        {props.data?.map(renderItem)}
      </View>
    </View>
  );
}

export default RadioView;

// PropTypes.oneOf([true, false, undefined])
RadioView.propTypes = {
  data: PropTypes.arrayOf(PropTypes.string),
  selected: PropTypes.string,
  onSelect: PropTypes.func,
  title: PropTypes.string,
};

RadioView.defaultProps = {};
