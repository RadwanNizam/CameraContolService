import { useNavigation } from "@react-navigation/native";
import React from "react";
import { I18nManager } from "react-native";
import { TouchableOpacity } from "react-native";
import { View, Text, StyleSheet, Dimensions, Image } from "react-native";
import { Layout } from "../constants";
import Colors from "../constants/Colors";
import SearchIcon from "./SearchIcon";
import { FontAwesome5, MaterialIcons } from "@expo/vector-icons";
/**
 * read the following information from props:
 * - props.title: optional
 * - props.search: boolean
 * - props.live: boolean
 *
 */
export const ScreenHeader = (props) => {
  const { color =  Colors.white } = props;
  const { canGoBack, goBack } = useNavigation();
  let title = null;
  if (props.title) {
    title = <Text style={[styles.screenTitle, {color}]}>{props.title}</Text>;
  }

  let right = null;
  if (props.search) {
    right = <SearchIcon navigigation={props.navigigation} />;
  } else if (props.filter) {
    right = (
      <TouchableOpacity onPress={props.onFilterPress}>
        <FontAwesome5 name="sliders-h" size={22} color={color} />
      </TouchableOpacity>
    );
  }

  let left = null;
 
  if(props.live){
    left = (
      <TouchableOpacity onPress={props.onLivePress}>
        <MaterialIcons name="live-tv" size={24} color={color} />
      </TouchableOpacity>
    );
  } else if ((typeof(props.back) == 'undefined' || props.back != false) && canGoBack()) {
    left = (
      <TouchableOpacity onPress={goBack}>
        <MaterialIcons name="arrow-back" size={24} color={color} />
      </TouchableOpacity>
    );
  }
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.leftContainer}>{left}</View>
      <View style={styles.centerContainer}>{title}</View>
      <View style={styles.rightContainer}>{right}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: "100%",
    flexDirection: Layout.leftDirection,
    paddingHorizontal: Layout.padding.content,
    justifyContent: "space-between",
    marginBottom: Layout.padding.normal,
    alignItems: "center",
    marginTop:15
  },
  screenTitle: {
    fontFamily: "cairo-bold",
    fontSize: 21,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0,
    color: Colors.fontColor1,
  },
  leftContainer: {
    flex: 0.2,
    alignItems: I18nManager.isRTL ? "flex-end" : "flex-start",
  },
  centerContainer: {
    alignItems: "center",
  },
  rightContainer: {
    flex: 0.2,
    alignItems: I18nManager.isRTL ? "flex-start" : "flex-end",
  },
});

export default ScreenHeader;
