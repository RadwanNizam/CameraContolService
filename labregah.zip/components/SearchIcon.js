import React from 'react' 
import { View, Text, StyleSheet, Image, Title } from 'react-native' 
import { TouchableOpacity } from 'react-native-gesture-handler';
import Colors from '../constants/Colors';
import { useNavigation } from '@react-navigation/native';
import { SCREEN_KEYS } from '../constants';
 
export const SearchIcon = (props) => { 
  const { navigate } = useNavigation()
  return ( 
    <TouchableOpacity onPress={()=> navigate(SCREEN_KEYS.SEARCH)}>
     <Image source={require('../assets/search.png')} />
   </TouchableOpacity>
   ); 
 } ;
 
 export default SearchIcon; 
