import React, { useState } from 'react';
import { FlatList, View, StyleSheet, Dimensions, Image, TouchableOpacity } from 'react-native';
import { isRTL } from '../services/i18n/index';
import { SearchBar, Button as ElementsButton, Icon } from 'react-native-elements';
import Colors from '../constants/Colors';

const SearchInput = props => {

    const [searchText, setSearchText] = useState('');

    const handleSearchTextChanged = () => {
        //console.log('searchText' + searchText);
    };

    return <SearchBar
        placeholder="ابحث في لبرقه ..."
        onChangeText={setSearchText}
        value={searchText}
        onFocus={() => { props.navigation.navigate('Search', {}) }}
        inputContainerStyle={{
            borderRadius: 10,
            overflow: "hidden",
            backgroundColor: Colors.primaryColor,
            borderWidth: 0,
        }}
        containerStyle={{
            width: '100%',
            overflow: "hidden",
            borderTopWidth: 0,
            borderBottomWidth: 0,
            backgroundColor: 'transparent',
            paddingBottom: 10,
        }}
        searchIcon={
            <Icon
                name='search'
                type='font-awesome'
                color='white'
                size={18}
                onPress={handleSearchTextChanged} />
        }
        inputStyle={{
            borderRadius: 20,
            overflow: "hidden",
            color: 'white',
            borderWidth: 0,
            backgroundColor: 'transparent',
            writingDirection: isRTL ? 'rtl' : 'ltr',
            fontFamily: 'cairo-light',
            fontSize: 16,

        }}
    />
};

export default SearchInput;