import React from "react";
import { View, StyleSheet } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";
import { t } from "../services/i18n";
import { ViewPropTypes } from "react-native";

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Layout.padding.content,
    paddingBottom: Layout.padding.medium,
  },
});

function SectionHeader(props) {
  return (
    <View style={[styles.container, props.style]}>
      <StyledText
        bold
        size={Fonts.size.large}
        color={props.color || Colors.fontColor2}
        children={props.title}
      />
      {props.more && (
        <StyledText
          bold
          touchable
          onPress={props.onMorePress}
          size={Fonts.size.medium}
          color={Colors.fontColor3}
          children={t("common:more")}
        />
      )}
    </View>
  );
}

export default SectionHeader;
// PropTypes.oneOf([true, false, undefined])
SectionHeader.propTypes = {
  title: PropTypes.string,
  more: PropTypes.oneOf([true, false, undefined]),
  onMorePress: PropTypes.func,
  style: ViewPropTypes.style,
};

SectionHeader.defaultProps = {};
