
import React from 'react';
import SVG,{Path, G, Circle} from 'react-native-svg';

const ShareIcon = props => {

    return <SVG xmlns="http://www.w3.org/2000/svg"   >
       
        <G fill="red" fillRule="evenodd" cx="50" r="45" strokeWidth="2.5"      stroke="blue"
            strokeWidth="2.5"
            cy="50">
            <G fill="green">
                <G>
                    <Path d="M12.013 3.392V.842c0-.336-.205-.641-.522-.774-.317-.133-.685-.068-.934.164L4.268 6.063c-.171.16-.268.38-.268.61 0 .231.097.451.268.61l6.289 5.831c.25.233.617.297.934.164.317-.132.523-.437.522-.774v-2.55c4.862 0 7.508 3.244 9.168 6.808.088.18.295.274.494.225.198-.049.334-.228.325-.427-.509-6.622-3.267-12.222-9.987-13.168z" transform="translate(-29 -282) translate(25 282) matrix(-1 0 0 1 26 0)" />
                </G>
            </G>
        </G>
    </SVG>
};

export default ShareIcon;