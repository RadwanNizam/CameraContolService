import React from 'react';
import { FlatList, View, StyleSheet, Dimensions, Image, TouchableOpacity, ImageBackground, Text } from 'react-native';
import { isRTL } from '../services/i18n/index';
import Title from '../components/Title';
import Colors from '../constants/Colors';
import moment from 'moment';
import { Layout } from '../constants';
const Slider = props => {

  const itemWidth = props.titleOverImage === 'true' ?
    (Dimensions.get("window").width * 4) / 5
    :
    (Dimensions.get("window").width * 3) / 5;
  const getSnapToOffsets = (data) => {
    var offsets = [];

    props.data.map(function (item, i) {
      if (i == 0) {
        offsets.push(0);
      } else {
        offsets.push(i * itemWidth - (itemWidth * 12.5 / 100));
      }
    });

    return offsets;
  }

  const renderItem = ({ item }) => {
    if (props.titleOverImage === 'true') {
      return (
        <View style={{ ...styles.postContainer, width: itemWidth }}>
          <TouchableOpacity
            onPress={() => props.navigation.navigate(props.targetRoute, { post: item, videoURL: props.loadMoreURL })}
          >
            <ImageBackground style={styles.ImageBackground} source={{ uri: item.featuredImgUrl }} imageStyle={styles.ImageBackgroundIntrnImg}>
              <View style={styles.child}>

              </View>
              <Image source={require('../assets/play.png')} style={styles.playVideoIcon} />
              <Text style={styles.titleOverImage} numberOfLines={2}>{item.title}</Text>

            </ImageBackground>

          </TouchableOpacity>
        </View>
      );
    } else {
      return (
        <View style={{ ...styles.postContainer, width: itemWidth }}>
          <TouchableOpacity
            onPress={() => props.navigation.navigate(props.targetRoute, { post: item })}
          >
            <View style={styles.imageContainer}>
              <Image source={{ uri: item.featuredImgUrl }} style={styles.postImage} />
            </View>
            <Text style={styles.postDate}>{moment(item.date).format("MMM DD - YYYY")}</Text>
            <Title numberOfLines={2} style={styles.titleUnderImage}>{item.title}</Title>
          </TouchableOpacity>
        </View>
      );
    }
  };

  return (
    <FlatList
      // onScroll = {}
      data={props.data}
      renderItem={item => renderItem(item)}
      horizontal
      keyExtractor={(item, index) => item.id.toString()}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{paddingHorizontal: Layout.padding.small}}
      disableIntervalMomentum={true}
      snapToOffsets={getSnapToOffsets(props.data)}
      disableScrollViewPanResponder={true}
      decelerationRate={0.985}
      snapToEnd={false}
      snapToStart={false}
      fadingEdgeLength={2}
    />
  );
};

const styles = StyleSheet.create({
  imageWrapper: {
    height: 200,
    width: 200,
    overflow: "hidden"
  },
  theImage: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
  slider: {
    flex: 1,
    justifyContent: 'center'
  },
  postContainer: {
    justifyContent: 'center',
    backgroundColor: 'transparent',
    paddingRight: 10,
    paddingLeft: 10
  },
  postImage: {
    width: '100%',
    aspectRatio: 16 / 9,
    borderRadius: 20
  },
  imageContainer: {
    borderRadius: 20,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  ImageBackground: {

    width: '100%',
    aspectRatio: 16 / 9,
    flexDirection: "column", justifyContent: "flex-end", alignItems: "center"
  },
  ImageBackgroundIntrnImg: {
    width: '100%',
    borderRadius: 20,
    shadowColor: "#00000033",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowRadius: 4,
    shadowOpacity: 1,
  },
  titleOverImage: {
    fontFamily: 'cairo-bold',
    fontSize: 16,
    fontWeight: "normal",
    fontStyle: "normal",
    lineHeight: 23,
    letterSpacing: 0,
    textAlign: "left",
    textAlignVertical: 'bottom',
    color: "#ffffff",
    paddingEnd: 20,
    paddingBottom: 10,
    paddingTop: 10
  },
  playVideoIcon: {
    paddingStart: 10,
    paddingBottom: 10
  },
  titleUnderImage: {

    fontFamily: 'cairo-regular',
    fontSize: 12,
    fontWeight: "normal",
    fontStyle: "normal",
    lineHeight: 23,
    letterSpacing: 0,
    textAlign: "left",
    textAlignVertical: 'bottom',
    color: Colors.fontColor2

  },
  postDate: {
    fontFamily: "cairo-bold",
    fontSize: 12,
    fontWeight: "normal",
    fontStyle: "normal",
    letterSpacing: 0,
    color: Colors.fontColor4,
    paddingTop: 5
  },
  child: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    // flex: 1,
    backgroundColor: 'rgba(0,0,0,0.1)',
    borderRadius: 20,
    // flex:1,
    // flexDirection: "column",
    // justifyContent: "flex-end",
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowRadius: 4,
    shadowOpacity: 1

  },

});

export default Slider;