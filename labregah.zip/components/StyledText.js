import React from "react";
import {
  Text,
  ViewPropTypes,
  TouchableOpacity,
  I18nManager,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { Fonts, Colors, Layout } from "../constants";
import PropTypes from "prop-types";

const styles = StyleSheet.create({
  rounded: {
    paddingVertical: Layout.padding.tiny,
    paddingHorizontal: Layout.padding.large,
    borderRadius: Layout.radius.round,
    backgroundColor: Colors.primaryColor,
  },
});

const TextComponent = (props) => (
  <Text
    {...props}
    style={[
      {
        fontFamily: props.bold ? Fonts.bold : Fonts.regular,
        textAlign: props.center
          ? "center"
          : I18nManager.isRTL
          ? "left"
          : "auto",
        fontSize: props.size,
        color: props.color,
      },
      props.style,
    ]}
  />
);
export default function StyledText(props) {
  if (!props.touchable) {
    return <TextComponent {...props} />;
  }
  const {
    containerProps,
    containerStyle,
    onPress,
    isLoading,
    loaderColor,
    rounded,
    ...rest
  } = props;

  return (
    <TouchableOpacity
      onPress={onPress}
      {...containerProps}
      style={[rounded && styles.rounded, containerStyle]}
    >
      {isLoading ? (
        <ActivityIndicator color={loaderColor} />
      ) : (
        <TextComponent {...rest} />
      )}
    </TouchableOpacity>
  );
}

StyledText.propTypes = {
  bold: PropTypes.oneOf([true, false, undefined]),
  center: PropTypes.oneOf([true, false, undefined]),
  rounded: PropTypes.oneOf([true, false, undefined]),
  size: PropTypes.number,
  color: PropTypes.string,
  loaderColor: PropTypes.string,
  containerProps: PropTypes.object,
  touchable: PropTypes.oneOf([true, false, undefined]),
  containerStyle: ViewPropTypes.style,
  children: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.array,
    PropTypes.object,
  ]),
  isLoading: PropTypes.oneOf([true, false, undefined]),
};

StyledText.defaultProps = {
  bold: false,
  center: false,
  rounded: false,
  size: Fonts.size.small,
  color: Colors.white,
  loaderColor: Colors.primaryColor,
  containerProps: {},
  touchable: false,
  containerStyle: {},
  children: "",
  isLoading: false,
};
