import React from "react";
import { View, StyleSheet } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";

const styles = StyleSheet.create({
  container: {},
});

function Template(props) {
  return <View style={styles.container}></View>;
}

export default Template;
// PropTypes.oneOf([true, false, undefined])
Template.propTypes = {};

Template.defaultProps = {};
