import React from "react";
import { StyleSheet, ViewPropTypes } from "react-native";
import { Layout, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import StyledText from "./StyledText";

const styles = StyleSheet.create({
  container: {
    borderRadius: Layout.radius.round,
    padding: Layout.padding.medium,
    marginTop: Layout.margin.normal,
    width: "100%",
  },
});

function TextButton({
  children,
  size,
  textColor,
  color,
  onPress,
  isLoading,
  disabled,
  ...props
}) {
  return (
    <StyledText
      center
      bold
      touchable
      children={children}
      size={size}
      color={textColor}
      containerStyle={[
        styles.container,
        { backgroundColor: color },
        props.style,
      ]}
      onPress={onPress}
      isLoading={isLoading}
      containerProps={disabled ? { disabled } : undefined}
    />
  );
}

export default TextButton;
// PropTypes.oneOf([true, false, undefined])
TextButton.propTypes = {
  bold: PropTypes.oneOf([true, false, undefined]),
  center: PropTypes.oneOf([true, false, undefined]),
  size: PropTypes.number,
  textColor: PropTypes.string,
  color: PropTypes.string,
  onPress: PropTypes.func,
  style: ViewPropTypes.style,
  children: PropTypes.string,
};

TextButton.defaultProps = {
  bold: false,
  center: false,
  size: Fonts.size.normal,
  textColor: Colors.primaryColor,
  color: Colors.white,
  onPress: () => {},
  style: {},
  children: "",
};
