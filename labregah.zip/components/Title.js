import React from 'react';
import { View, StyleSheet, Text} from 'react-native';
import {isRTL} from '../services/i18n/index';

const Title = props => {

    const fontFamily = fontWeight => {
        switch(fontWeight) {
            case 1:
                return {fontFamily: 'cairo-extralight'};
            case 2: 
                return {fontFamily: 'cairo-light'};
            case 3: 
                return {fontFamily: 'cairo-regular'};
            case 4: 
                return {fontFamily: 'cairo-semibold'};
            case 5: 
                return {fontFamily: 'cairo-bold'};
            case 5: 
                return {fontFamily: 'cairo-black'};
            default:
                return {fontFamily: 'cairo-regular'};
        }
    };
    
    return <View style={styles.container}>
        <Text numberOfLines={props.numberOfLines} 
            style={{...styles.title, ... fontFamily(props.fontWeight), ...props.style}}>
                {props.children}
        </Text>
    </View>
};

const styles = StyleSheet.create({
    container:{
        width: '100%'     
    },
    title:{         
    //   textAlign: isRTL ? 'right':'left',
    //   writingDirection: isRTL ? 'rtl':'ltr',
       writingDirection: isRTL ? 'rtl':'ltr',
      paddingTop: 5
    }    
});

export default Title; 
