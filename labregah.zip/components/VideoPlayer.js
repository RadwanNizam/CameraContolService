import React, { useMemo, useState, useRef } from "react";
import { View, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { Layout, Styles, Fonts, Colors } from "../constants";
import PropTypes from "prop-types";
import Modal from "react-native-modal";
import {
  SafeAreaView,
  useSafeAreaInsets,
} from "react-native-safe-area-context";
import StyledText from "./StyledText";
import TextButton from "./TextButton";
import { MaterialIcons } from "@expo/vector-icons";
import RadioButton from "./RadioButton";
import BubbleView from "./BubbleView";
import RadioView from "./RadioView";
import { t } from "../services/i18n";
import YoutubePlayer from 'react-native-youtube-iframe';

const styles = StyleSheet.create({
  container: { flex: 1 },
  modal: {
    margin: 0,
    backgroundColor: Colors.white,
    justifyContent: "flex-start",
  },
  headerContainer: {
    flexDirection: "row",
    paddingHorizontal: Layout.padding.content,
    justifyContent: "space-between",
    alignItems: "center",
  },
  searchButtonContainer: {
    paddingHorizontal: Layout.margin.content,
    marginTop: Layout.margin.normal,
  },
});

function VideoPlayer(props) {
  const {
    visible,
    setVisible,
    fields = [],
    days = [],
    categories = [],
    periods = [],
    invitations = [],
    classes = [],
  } = props;
  const open = () => setVisible(true);
  const close = () => setVisible(false);
  const [selectedField, setSelectedField] = useState("");
  const [selectedDay, setSelectedDay] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [selectedInvitation, setSelectedInvitation] = useState("");
  const [selectedClass, setSelectedClass] = useState("");
  const playerRef = useRef(null);
  return (
    <Modal isVisible={visible} style={styles.modal} onSwipeComplete={close}>
      <SafeAreaView>
        <View style={styles.headerContainer}>
          <View style={{ flex: 0.25 }} />
          {/* <StyledText
            bold
            color={Colors.gray}
            size={Fonts.size.large}
            children={t("common:filterSearch")}
          /> */}
          <View style={{ flex: 0.25, alignItems: "flex-end" }}>
            <TouchableOpacity
              style={{ padding: Layout.padding.tiny }}
              onPress={close}
            >
              <MaterialIcons name="close" size={24} color="black" />
            </TouchableOpacity>
          </View>
        </View>
        <View style={{bottom:100, height:500, display:'flex', flexDirection:"column-reverse"}}>
          <View>
                <YoutubePlayer 
                          ref={playerRef}
                          height={500}
                          width="100%"
                          
                          videoId="h6lB0RybYWo"
                          play={true}
                          // onChangeState={event => console.log(event)}
                          // onReady={() => console.log("ready")}
                          // onError={e => console.log(e)}
                          onPlaybackQualityChange={q => console.log(q)}
                          volume={50}
                          playbackRate={1}
                          playerParams={{
                            cc_lang_pref: "us",
                            showClosedCaptions: true,
                            allowsFullscreenVideo: true
                          }}
                        />
        </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

export default VideoPlayer;

VideoPlayer.propTypes = {
  visible: PropTypes.oneOf([true, false, undefined]),
  setVisible: PropTypes.func,
};

VideoPlayer.defaultProps = {};
