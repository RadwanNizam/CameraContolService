import React from 'react' 
import { View, Text, StyleSheet, Image, Title } from 'react-native' 
import { TouchableOpacity } from 'react-native-gesture-handler';
import Colors from '../../constants/Colors';
import moment from 'moment';



  
export const VideoPaper = (props) => { 
  const {video} = props;
  return ( 
     <View style={styles.paper}> 
      {/* <TouchableOpacity 
        onPress={ () => props.navigation.navigate(props.targetRoute, {post: item})}
      >         */}
      <View style={styles.paperContainer}>
        <Image source={{ uri: video.featuredImgUrl }} style={styles.featuredImage} />
        <View style={{flex:1, flexDirection:"column", justifyContent:"space-between"}}>
            <Text   numberOfLines={2} style={styles.videoTitle}>{video.title}</Text>
            <Text style={styles.postDate}>{moment(video.date).format("MMM DD - YYYY")}</Text>

        </View>
        </View>
      {/* </TouchableOpacity>         */}
    </View>
   ); 
 } ;

 const styles = StyleSheet.create({ 
    paper: { 
      paddingBottom:10,
      paddingTop:10,
      borderWidth:0,
    
     },paperContainer:{
        display:"flex",
        flexDirection:"row",
        backgroundColor:'white',
        shadowColor: "#404b6319",
        shadowOffset: {
          width: 0,
          height: 10
        },
        shadowRadius: 20,
        shadowOpacity: 1,

        borderRadius: 14,
        backgroundColor: Colors.secondaryColor,
      
        borderStyle: "solid",
        borderWidth: 1,
        borderColor: Colors.forthColor, 
        marginStart:36, marginEnd:36          

     }, 
     featuredImage:{
        // borderRadius: 14,
        // borderBottomStartRadius: 14,
        borderTopLeftRadius:14,
        borderBottomLeftRadius:14,
        backgroundColor: Colors.secondaryColor,
        width:'50%',
        aspectRatio:16/9
     },  postDate:{
        fontFamily: "cairo-bold",
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        letterSpacing: 0,
        color: Colors.fontColor4,
        paddingTop: 5,
        textAlign:"left",
        paddingStart: 5,
        paddingBottom: 5

      },videoTitle:{
        fontFamily: "cairo-bold",
        fontSize: 11,
        fontWeight: "bold",
        fontStyle: "normal",
        letterSpacing: 0,
        color: "#4a4a4a",
        textAlign: "left",
        paddingStart:5,
        paddingTop:5
      }
 }); 
    
 

 export default VideoPaper; 
