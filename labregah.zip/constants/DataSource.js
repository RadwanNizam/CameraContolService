const API_GATEWAY_URL = 'https://zaia8relz9.execute-api.eu-west-1.amazonaws.com/production';
export const VIDEO_URL_QUERY_PARAMS = '_embed&_fields=id,_embedded,_links,title,guid,featured_media,link,content,date';
export const NEWS_POST_URL_QUERY_PARAMS = '_embed&_fields=id,_embedded,_links,title,featured_media,link,guid,date';
export const PROGRAM_URL_QUERY_PARAMS = '_embed&_fields=id,_embedded,_links,title,content,guid,featured_media,date';

export default {
    home_videos_url:   API_GATEWAY_URL+'/videos/featured',//'https://labregah.org/wp-json/wp/v2/video/?per_page=5&categories=62&'+VIDEO_URL_QUERY_PARAMS,
    latest_videos_url: API_GATEWAY_URL+'/videos',//'https://labregah.org/wp-json/wp/v2/video/?per_page=5&'+VIDEO_URL_QUERY_PARAMS,
    video_post_url:    API_GATEWAY_URL+'/videos/' , // videoid parameter should be passed
    
    home_page_news_url: API_GATEWAY_URL+'/news/featured',//'https://labregah.org/wp-json/wp/v2/news?per_page=5&categories=60&'+NEWS_POST_URL_QUERY_PARAMS,
    latest_news_url: API_GATEWAY_URL+'/news',//'https://labregah.org/wp-json/wp/v2/news?per_page=5&'+NEWS_POST_URL_QUERY_PARAMS,
    news_post_url: API_GATEWAY_URL+'/news/', // post id parameter should be passed

    latest_program_winners_url: API_GATEWAY_URL+'/programs/winners',//'https://labregah.org/wp-json/wp/v2/program/?per_page=5&categories=67&'+PROGRAM_URL_QUERY_PARAMS,
    latest_program_ezpaty_url: API_GATEWAY_URL+'/programs/ezpaty',//'https://labregah.org/wp-json/wp/v2/program/?per_page=5&categories=69&'+PROGRAM_URL_QUERY_PARAMS,
    latest_program_labregah_yeard_url: API_GATEWAY_URL+'/programs/labregah-yeard',//'https://labregah.org/wp-json/wp/v2/program/?per_page=5&categories=66&'+PROGRAM_URL_QUERY_PARAMS,
    latest_program_stars_url: API_GATEWAY_URL+'/programs/stars',//'https://labregah.org/wp-json/wp/v2/program/?per_page=5&categories=113&'+PROGRAM_URL_QUERY_PARAMS,
    program_url: API_GATEWAY_URL+'/programs/', // program id should be passed

    
    racing_videos_countries_url: API_GATEWAY_URL + '/racing/video/search/country',
    racing_videos_seasons_url: API_GATEWAY_URL + '/racing/video/search/season',
    racing_videos_festivals_url: API_GATEWAY_URL + '/racing/video/search/festival',
    search_racing_videos_url: API_GATEWAY_URL + '/racing/video',
    fetch_race_videos: API_GATEWAY_URL + '/racing/video/items',

    racing_results_countries_url: API_GATEWAY_URL + '/racing/results/search/country',
    racing_results_seasons_url: API_GATEWAY_URL + '/racing/results/search/season',
    racing_results_festivals_url: API_GATEWAY_URL + '/racing/results/search/festival',
    search_racing_results_url: API_GATEWAY_URL + '/racing/results',
    fetch_race_results: API_GATEWAY_URL + '/racing/results/items',

    racing_dates_countries_url: API_GATEWAY_URL + '/racing/dates/search/country',
    racing_dates_seasons_url: API_GATEWAY_URL + '/racing/dates/search/season',
    racing_dates_festivals_url: API_GATEWAY_URL + '/racing/dates/search/festival',
    search_racing_dates_url: API_GATEWAY_URL + '/racing/dates',
    // fetch_race_dates: 'https://zaia8relz9.execute-api.eu-west-1.amazonaws.com/production/racing/dates/items',
    store_notification_token: 'https://zaia8relz9.execute-api.eu-west-1.amazonaws.com/production/account/mobile/notification/token',
    production: 'https://zaia8relz9.execute-api.eu-west-1.amazonaws.com/production'
}