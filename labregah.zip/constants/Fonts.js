const type = {
  regular: "cairo-regular",
  bold: "cairo-bold",
};

const size = {
  title: 28,

  xxLarge: 42,
  xLarge: 24,
  large: 21,
  normal: 16,
  medium: 14,
  small: 12,
  extraSmall: 10,
  tiny: 8,
  extraTiny: 6,
};

const style = {};

export default {
  ...type,
  type,
  size,
  style,
};
