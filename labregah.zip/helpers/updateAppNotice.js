import { Linking, Platform } from "react-native";
import { Alert } from "react-native";

export default function updateAppNotice() {
  const APP_STORE_LINK =
    "itms://itunes.apple.com/us/app/apple-store/id1478017860?mt=8";
  const PLAY_STORE_LINK = "market://details?id=com.uvita.io";
  Alert.alert(
    "Update Available",
    "This version of Labregah app is out of date. Please update app from the " +
      (Platform.OS == "ios" ? "App Store" : "Google Play.") +
      ".",
    [
      {
        text: "Update Now",
        onPress: () => {
          if (Platform.OS == "ios") {
            Linking.openURL(APP_STORE_LINK).catch((err) =>
              console.log("An error occurred", err)
            );
          } else {
            Linking.openURL(PLAY_STORE_LINK).catch((err) =>
              console.log("An error occurred", err)
            );
          }
        },
      },
    ],
    { cancelable: false }
  );
}
