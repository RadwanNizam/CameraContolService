import React from "react";

export const Context = React.createContext();

export default function useAppContext() {
  return React.useContext(Context);
}
