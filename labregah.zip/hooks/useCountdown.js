import React, { useState, useEffect } from "react";

export default function useCountdown(count = 60) {
  const [countdown, setCountdown] = useState(count);
  useEffect(() => {
    if (!countdown) return;
    const intervalId = setInterval(() => {
      setCountdown(countdown - 1);
    }, 1000);
    return () => clearInterval(intervalId);
  }, [countdown]);
  const reset = () => setCountdown(count);
  return { countdown, reset };
}
