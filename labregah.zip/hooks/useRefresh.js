import { useEffect, useRef } from "react";
import moment from "moment";
import { useNavigation } from "@react-navigation/native";

export default function useRefresh(refresh) {
  const { addListener } = useNavigation();
  const lastRefreshDate = useRef(moment());
  const resetLastRefreshDate = () => {
    lastRefreshDate.current = moment();
  };

  useEffect(() => {
    const unsubscribe = addListener("focus", () => {
      if (moment().diff(lastRefreshDate.current, "minutes") >= 5) {
        try {
          refresh();
          resetLastRefreshDate();
        } catch (error) {
          console.log(error);
        }
      }
    });
    return unsubscribe;
  }, [lastRefreshDate]);

  return {
    resetLastRefreshDate,
    lastRefreshDate,
  };
}
