export default function useRegex() {
  const phoneRegex = /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/g;
  const nameRegex = /^[\u0621-\u064A\s0-9a-zA-Z٠-٩]+$/;
  return {
    phone: (phone) => phoneRegex.test(phone),
    name: (name) => nameRegex.test(name),
  };
}
