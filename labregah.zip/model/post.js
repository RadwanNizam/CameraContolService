class Post {
    constructor(id, title, featuredImgUrl, url) {
        this.id = id;
        this.title = title;
        this.featuredImgUrl = featuredImgUrl;
        this.date = new Date();
        this.url = url;
    }
}

export default Post;