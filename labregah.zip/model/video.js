class Post {
    constructor(id, title, featuredImgUrl, videoURL, postURL) {
        this.id = id;
        this.title = title;
        this.featuredImgUrl = featuredImgUrl;
        this.date = new Date();
        this.videoURL = videoURL;
        this.postURL = postURL;
    }
}

export default Post;