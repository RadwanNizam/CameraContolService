import React, { useRef, useEffect } from "react";
import { SCREEN_KEYS } from "../constants";
import * as Notifications from "expo-notifications";
import App from "../screens/AppNavigator";
import { handleFetchErrors } from "../utils/FetchData";
import { getPost } from "../utils/PostLoader";

export default function AppNavigator({ navigation }) {
  const notificationListener = useRef();
  const responseListener = useRef();

  useEffect(() => {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
      }),
    });

    const openScreen = async (item) => {
      try {
        const post = await getPost(item);
        switch (item.subtype) {
          case "program":
          case "video":
            navigation.navigate(SCREEN_KEYS.VIDEO, { post });
            break;
          case "news":
            navigation.navigate(SCREEN_KEYS.NEWS_POST, { post });
            break;
        }
      } catch (error) {
        console.log(error);
        handleFetchErrors(error);
      }
    };
    // This listener is fired whenever a notification is received while the app is foregrounded
    notificationListener.current = Notifications.addNotificationReceivedListener(
      (notification) => {
        // console.log("notification 1", notification);
        // console.log("title", notification.request.content.title);
        // console.log("body", notification.request.content.body);
        // console.log("type", notification.request.content.data.type);
        // console.log("sub-type", notification.request.content.data.subtype);
        // console.log("id", notification.request.content.data.id);
        // console.log("title", notification.request.content.data.title);
        // openScreen(notification.request.content.data);
      }
    );

    // This listener is fired whenever a user taps on or interacts with a notification (works when app is foregrounded, backgrounded, or killed)
    responseListener.current = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        try {
          openScreen(response.notification.request.content.data);
        } catch (error) {}
      }
    );

    return () => {
      Notifications.removeNotificationSubscription(
        notificationListener.current
      );
      Notifications.removeNotificationSubscription(
        notificationListener.current
      );
    };
  }, []);

  return <App />;
}
