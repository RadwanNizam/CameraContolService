import * as React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import { SCREEN_KEYS } from "../constants";
import {
  LoginScreen,
  CreateAccountScreen,
  SplashScreen,
  VerifyCodeScreen,
} from "../screens";

const Stack = createStackNavigator();

export default function AuthNavigator() {
  return (
    <Stack.Navigator
      initialRouteName={SCREEN_KEYS.SPLASH}
      screenOptions={{ headerShown: false }}
    >
      <Stack.Screen name={SCREEN_KEYS.SPLASH} component={SplashScreen} options={{animationEnabled: false}} />
      <Stack.Screen name={SCREEN_KEYS.LOGIN} component={LoginScreen} options={{animationEnabled: false}} />
      <Stack.Screen
        name={SCREEN_KEYS.CREATE_ACCOUNT}
        component={CreateAccountScreen}
      />
      <Stack.Screen
        name={SCREEN_KEYS.VERIFY_CODE}
        component={VerifyCodeScreen}
      />
    </Stack.Navigator>
  );
}
