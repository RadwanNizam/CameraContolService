import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import AppNavigator from "./AppNavigator";
import AuthNavigator from "./AuthNavigator";
import { Context } from "../hooks/useAppContext";
import { Auth, Hub } from "aws-amplify";

const Stack = createStackNavigator();

export default function Navigation() {
  const [isLogged, setIsLogged] = React.useState(false);
  const context = {
    isLogged,
    setIsLogged,
    signOut: () => {
      Auth.signOut();
      setIsLogged(false);
    },
  };
  React.useLayoutEffect(() => {
    Auth.currentAuthenticatedUser()
      .then(() => setIsLogged(true))
      .catch(() => setIsLogged(false));
    Hub.listen("auth", (data) => {
      switch (data.payload.event) {
        case "tokenRefresh_failure":
          if (data.payload.data?.code == "NotAuthorizedException") {
            context.signOut();
          }
      }
    });
  }, []);
  return (
    <Context.Provider value={context}>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          {isLogged ? (
            <Stack.Screen name="App" component={AppNavigator} />
          ) : (
            <Stack.Screen name="Auth" component={AuthNavigator} />
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </Context.Provider>
  );
}
