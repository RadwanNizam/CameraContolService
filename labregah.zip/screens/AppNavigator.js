import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons'

import Colors from '../constants/Colors';

import HomeScreen, {screenOptions as homeScreenOptions} from './HomeScreen';
import VideosScreen, {screenOptions as videosScreenOptions} from './VideosScreen';
import NewsScreen, {screenOptions as newsScreenOptions} from './NewsScreen';
import PhotosScreen, {screenOptions as photosScreenOptions} from './PhotosScreen';
import CalendarScreen, {screenOptions as calendarScreenOptions} from './CalendarScreen';
import ResultsScreen, {screenOptions as resultsScreenOptions} from './ResultsScreen';
import RacingDatesScreen, {screenOptions as datesScreenOptions} from './RacingDatesScreen';
import RacingVideosScreen, {screenOptions as racingVideosScreenOptions} from './RacingVideosScreen';
import {screenOptions as racingResultsScreenOptions} from './RacingResultsScreen';
import {RaceVideosScreen, raceVideosScreenOptions, RaceResultsScreen, raceResultsScreenOptions, RacingResultsScreen, MoreScreen} from './index';
import SettingsScreen, {screenOptions as settingsScreenOptions} from './SettingsScreen';
import VideoScreen, {screenOptions as videoScreenOptions} from './VideoScreen';
import NewsPostScreen, {screenOptions as newsPostScreenOptions} from './NewsPostScreen';
import SearchScreen, {screenOptions as searchScreenOptions} from './SearchScreen';
import ProgramsScreen, {screenOptions as programsScreenOptions} from './ProgramsScreen';

import {
  SafeAreaView,
  SafeAreaProvider,
  SafeAreaInsetsContext,
  useSafeAreaInsets,
  initialWindowMetrics,
} from 'react-native-safe-area-context';

import {t} from '../services/i18n';
import { SCREEN_KEYS } from '../constants';
import { CalendarIcon, HomeIcon, MoreIcon, NewsIcon, VideosIcon } from '../assets/svg';
import DataSource from '../constants/DataSource';

const stackNavDefaultScreenOptions = {
    headerStyle:{
       backgroundColor:  Colors.primaryColor ,
       height:80
    },
    headerTitleStyle: {
        fontFamily: 'open-sans-bold',
    }, 
    headerBackTitleStyle: { // style of the text near the back button (only IOS)
        fontFamily: 'open-sans',
    },
    headerBackTitleVisible: false,
    headerShown: false
    //headerTintColor: Platform.OS === 'android' ?  'white' : Colors.primaryColor

};

const HomeStack = createStackNavigator();
function HomeStackScreen() {
  return (    
    <HomeStack.Navigator screenOptions={stackNavDefaultScreenOptions}>
      <HomeStack.Screen name="Home" component={HomeScreen} options={homeScreenOptions} />
      <HomeStack.Screen name="News" component={NewsScreen}  options={newsScreenOptions}/>
      <HomeStack.Screen name="VIDEO" component={VideosScreen}  options={videosScreenOptions} initialParams={{videoURL:DataSource.latest_videos_url}}/>
      {/* <HomeStack.Screen name="Photos" component={PhotosScreen}  options={photosScreenOptions} /> */}
      <HomeStack.Screen name="Video" component={VideoScreen}  options={videosScreenOptions} />
      <HomeStack.Screen name="NewsPost" component={NewsPostScreen}  options={newsPostScreenOptions} /> 
      <HomeStack.Screen name="Search" component={SearchScreen}  options={searchScreenOptions} />  
      <HomeStack.Screen name="Programs" component={ProgramsScreen}  options={programsScreenOptions} />  
      <HomeStack.Screen name={SCREEN_KEYS.RACING_RESULTS} component={RacingResultsStackScreen} options={racingResultsScreenOptions} /> 
      <HomeStack.Screen name={SCREEN_KEYS.RACING_VIDEOS} component={RacingVideosStackScreen} options={racingVideosScreenOptions} />       
    </HomeStack.Navigator>  
  );
};

const VideosStack = createStackNavigator();
function VideosStackScreen() {
  return (
    <VideosStack.Navigator screenOptions={stackNavDefaultScreenOptions}>
      <VideosStack.Screen name="Videos" component={VideosScreen} options={videosScreenOptions}/>
      <VideosStack.Screen name="Video"  component={VideoScreen}  options={videoScreenOptions}/>
    </VideosStack.Navigator>
  );
};

const RacingVideosStack = createStackNavigator();
function RacingVideosStackScreen() {
  return (
    <RacingVideosStack.Navigator screenOptions={stackNavDefaultScreenOptions}>
      <RacingVideosStack.Screen name={SCREEN_KEYS.RACING_VIDEOS} component={RacingVideosScreen} options={racingVideosScreenOptions}/>
      <RacingVideosStack.Screen name={SCREEN_KEYS.RACE_VIDEOS} component={RaceVideosScreen} options={raceVideosScreenOptions}/>
      <RacingVideosStack.Screen name='Video' component={VideoScreen} options={videoScreenOptions}/>
    </RacingVideosStack.Navigator>
  );
};

const RacingResultsStack = createStackNavigator();
function RacingResultsStackScreen() {
  return (
    <RacingResultsStack.Navigator screenOptions={stackNavDefaultScreenOptions}>
      <RacingResultsStack.Screen name={SCREEN_KEYS.RACING_RESULTS} component={RacingResultsScreen} options={racingResultsScreenOptions}/>
      <RacingResultsStack.Screen name={SCREEN_KEYS.RACE_RESULTS} component={RaceResultsScreen} options={raceResultsScreenOptions}/>
      <RacingResultsStack.Screen name='Video' component={VideoScreen} options={videoScreenOptions}/>
    </RacingResultsStack.Navigator>
  );
};

const RacingDatesStack = createStackNavigator();
function RacingDatesStackScreen() {
  return (
    <RacingDatesStack.Navigator screenOptions={stackNavDefaultScreenOptions}>
      <RacingDatesStack.Screen name={SCREEN_KEYS.RACING_VIDEOS} component={RacingVideosScreen} options={racingVideosScreenOptions}/>
      <RacingDatesStack.Screen name={SCREEN_KEYS.RACE_VIDEOS} component={RaceVideosScreen} options={raceVideosScreenOptions}/>
      <RacingDatesStack.Screen name='Video' component={VideoScreen} options={videoScreenOptions}/>
    </RacingDatesStack.Navigator>
  );
};

const NewsStack = createStackNavigator();
function NewsStackScreen() {
  return (
    <NewsStack.Navigator screenOptions={stackNavDefaultScreenOptions}>
      <NewsStack.Screen name="News" component={NewsScreen} options={newsScreenOptions}/>
      <NewsStack.Screen name="NewsPost"  component={NewsPostScreen}  options={newsPostScreenOptions}/>
    </NewsStack.Navigator>
  );
};

const PhotosStack = createStackNavigator();
function PhotosStackScreen() {
  return (
    <NewsStack.Navigator screenOptions={stackNavDefaultScreenOptions}>
      <NewsStack.Screen name="Photos" component={PhotosScreen} options={photosScreenOptions}/>
    </NewsStack.Navigator>
  );
};

// const MoreStack = createStackNavigator();
// function MoreStackStackScreen() {
//   return (
//     <MoreStack.Navigator screenOptions={stackNavDefaultScreenOptions}>
//       <MoreStack.Screen name={SCREEN_KEYS.MORE} component={MoreScreen}  options={{tabBarIcon: MoreIcon}}/>
//     </MoreStack.Navigator>
//   );
// };

const tabNavDefaultScreenOptions = ({ route }) => ({
    tabBarLabel: t('BottomTabNavigator:' + route.name),
  });
  
  const tabNavDefaultTabBarOptions = {
    activeTintColor: Colors.primaryColor,
    inactiveTintColor: '#c5cee0',    
  };

const Tab = createBottomTabNavigator();

const tabListeners = (name, initial) => ({ navigation, route }) => ({
  tabPress: e => {
    e.preventDefault();
    navigation.jumpTo(name, {screen: initial});
  },
})

const TabNavigator = props => {
    return (
      <Tab.Navigator screenOptions={tabNavDefaultScreenOptions} 
        tabBarOptions={tabNavDefaultTabBarOptions}>
            <Tab.Screen
              name={SCREEN_KEYS.HOME} component={HomeStackScreen} options={{tabBarIcon: HomeIcon}}
              listeners={tabListeners(SCREEN_KEYS.HOME, "Home")}
            />
            <Tab.Screen
              name={SCREEN_KEYS.NEWS} component={NewsStackScreen} options={{tabBarIcon: NewsIcon}}
              listeners={tabListeners(SCREEN_KEYS.NEWS, "News")}
            />
            <Tab.Screen
              name={SCREEN_KEYS.VIDEOS} component={VideosStackScreen} options={{tabBarIcon: VideosIcon}}
              listeners={tabListeners(SCREEN_KEYS.VIDEOS, "Videos")}
            />
            
            {/* <Stack.Screen name="Photos" component={PhotosStackScreen} /> */}
            {/* <Stack.Screen name="Calendar" component={CalendarScreen} />
            <Stack.Screen name="Results" component={ResultsScreen} /> */}
            <Tab.Screen
              name={SCREEN_KEYS.RACING_DATES} component={RacingDatesScreen} options={{tabBarIcon: CalendarIcon}}
            /> 
            <Tab.Screen name={SCREEN_KEYS.MORE} component={MoreScreen} options={{tabBarIcon: MoreIcon}} /> 

      </Tab.Navigator>        
    );
}

const Stack = createStackNavigator();
 
const AppNavigator = props => {
  return (
    <Stack.Navigator initialRouteName={SCREEN_KEYS.MAIN_TAB} screenOptions={{headerShown: false}}>
      <Stack.Screen name={SCREEN_KEYS.MAIN_TAB} component={TabNavigator} />
      <Stack.Screen name={SCREEN_KEYS.RACE_VIDEOS} component={RaceVideosScreen} />
      <Stack.Screen name={SCREEN_KEYS.RACE_RESULTS} component={RaceResultsScreen} />
      <Stack.Screen name={SCREEN_KEYS.SEARCH} component={SearchScreen} />
      <Stack.Screen name={SCREEN_KEYS.VIDEO} component={VideoScreen}  options={videosScreenOptions} />
      <Stack.Screen name={SCREEN_KEYS.NEWS_POST} component={NewsPostScreen}  options={newsPostScreenOptions} />
    </Stack.Navigator>
  );
}
export default AppNavigator;