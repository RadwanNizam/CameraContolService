import React from 'react';
import {View, Text, StyleSheet} from 'react-native';


function CalendarScreen ({ route, navigation }) {
    return (    
        <View><Text>Calendar Screen</Text></View>    
    )
};

export 
const styles = StyleSheet.create({
    screen:{
    }
});

export default CalendarScreen;