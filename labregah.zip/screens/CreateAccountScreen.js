import React, { useState, useEffect, useMemo } from "react";
import {
  StyleSheet,
  View,
  Keyboard,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
} from "react-native";
import { Colors, Fonts, Layout, SCREEN_KEYS } from "../constants";
import PhoneInput from "../components/PhoneInput";
import TextButton from "../components/TextButton";
import { Auth } from "aws-amplify";
import useRegex from "../hooks/useRegex";
import StyledText from "../components/StyledText";
import Toast from "react-native-toast-message";
import NameInput from "../components/NameInput";

export default function CreateAccountScreen(props) {
  const regex = useRegex();
  const [loading, setLoading] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState({
    callingCode: "974",
    cca2: "QA",
    number: "",
  });

  const number = useMemo(
    () =>
      `+${phone.callingCode}${
        phone.number.startsWith("0") ? phone.number.substring(1) : phone.number
      }`,
    [phone]
  );
  const [nameError, setNameError] = useState("");
  const [phoneError, setPhoneError] = useState("");
  useEffect(() => {
    if (phoneError) setPhoneError("");
  }, [phone]);
  useEffect(() => {
    if (nameError) setNameError("");
  }, [firstName, lastName]);
  const onSuccess = async () => {
    const user = await Auth.signIn(number).catch((error) => {
      Toast.show({
        position: "bottom",
        type: "error",
        text1: "حدث خطأ",
        text2: error.message,
      });
    });
    setLoading(false);
    props.navigation.navigate(SCREEN_KEYS.VERIFY_CODE, { user });
  };

  const onSignupPress = () => {
    const given_name = firstName?.trim();
    const family_name = lastName?.trim();
    if (!given_name || !family_name) return setNameError("قم بملئ الحقول");
    if (!regex.name(given_name) || !regex.name(family_name))
      return setNameError("يجب أن يتكون الاسم من أحرف أبجدية وأرقام فقط");

    if (!phone.number || !regex.phone(number))
      return setPhoneError("الرقم غير صالح");
    setLoading(true);

    Auth.signUp({
      username: number,
      password: Math.random().toString(10) + "Abc#",
      attributes: {
        phone_number: number,
        given_name,
        family_name,
        name: given_name + " " + family_name,
      },
    })
      .then(onSuccess)
      .catch((error) => {
        if (error?.code == "UsernameExistsException") {
          Toast.show({
            position: "bottom",
            type: "info",
            text1: "هذا الرقم مسجل مسبقاً",
          });
          return onSuccess();
        }
        Toast.show({
          position: "bottom",
          type: "error",
          text1: "فشلت عملية التسجيل",
          text2: error?.message,
        });
        setLoading(false);
      });
  };

  const onLoginPress = () => {
    props.navigation.navigate(SCREEN_KEYS.LOGIN);
  };
  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={"padding"}
        enabled={Layout.isIOS}
      >
        <View style={styles.container}>
          <StyledText children={"إنشاء حساب"} bold size={Fonts.size.title} />
          <StyledText
            style={styles.subtitle}
            children={"أنشئ حساباً على موقع لبرقه"}
          />
          <NameInput
            error={nameError}
            firstName={firstName}
            lastName={lastName}
            setFirstName={setFirstName}
            setLastName={setLastName}
          />

          <PhoneInput phone={phone} onChange={setPhone} error={phoneError} />
          <TextButton
            disabled={loading}
            children={"أنشئ حسابي"}
            onPress={onSignupPress}
            isLoading={loading}
            style={styles.loginButton}
          />
          <View style={styles.row}>
            <StyledText children={"هل لديك حساب؟"} />
            <StyledText
              touchable
              containerStyle={{ padding: Layout.padding.small }}
              children={"تسجيل الدخول"}
              onPress={onLoginPress}
            />
          </View>
        </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.primaryColor,
    padding: Layout.padding.large,
  },
  subtitle: {
    marginTop: Layout.margin.small,
    marginBottom: Layout.margin.xLarge,
  },
  loginButton: {
    marginBottom: Layout.margin.normal,
    marginTop: Layout.margin.large,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
  },
});
