import React, { useEffect, useState, useCallback } from "react";
import { View, StyleSheet, RefreshControl } from "react-native";
import Slider from "../components/Slider";
import { t } from "../services/i18n";
import { useSelector, useDispatch } from "react-redux";
import {
  fetchLatestNews,
  fetchLatestPrograms,
  fetchLatestVideos,
} from "../store/actions/homeActions";
import LabregahProgramsView from "../components/LabregahProgramsView";
import { Layout, Colors, SCREEN_KEYS } from "../constants";
import Screen from "./Screen";
import SectionHeader from "../components/SectionHeader";
import DataSource from "../constants/DataSource";
import { getLoadMoreURL } from "../utils/Programs";
import useRefresh from "../hooks/useRefresh";

function HomeScreen({ route, navigation }) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState();
  const latestNews = useSelector((state) => state.home.latestNews);
  const latestVideos = useSelector((state) => state.home.latestVideos);
  const latestPrograms = useSelector((state) => state.home.latestPrograms);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const dispatch = useDispatch();
  const onProgramPress = (program) => {
    navigation.navigate("Video", {
      post: program,
      videoURL: getLoadMoreURL(program.postType),
    });
  };
  const onRefresh = () => {
    setIsRefreshing(true);
    Promise.all([
      dispatch(fetchLatestNews()),
      dispatch(fetchLatestPrograms()),
      dispatch(fetchLatestVideos()),
    ]).finally(() => {
      setIsRefreshing(false);
    });
  };
  const refreshData = () => {
    Promise.all([
      dispatch(fetchLatestNews()),
      dispatch(fetchLatestPrograms()),
      dispatch(fetchLatestVideos()),
    ]);
  };
  const { resetLastRefreshDate } = useRefresh(refreshData);

  const loadHomePageInfo = useCallback(async () => {
    setError(null);
    setIsLoading(true);
    try {
      await Promise.all([
        dispatch(fetchLatestNews()),
        dispatch(fetchLatestPrograms()),
        dispatch(fetchLatestVideos()),
      ]);
      resetLastRefreshDate();
    } catch (err) {
      setError(err.message);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadHomePageInfo();
  }, [loadHomePageInfo]); // will run only when the component is loaded

  const onVideosMorePress = () => {
    navigation.navigate(SCREEN_KEYS.VIDEOS);
  };
  const onNewsMorePress = () => {
    navigation.navigate(SCREEN_KEYS.NEWS);
  };
  const onProgramsMorePress = () => {
    navigation.navigate("Programs");
  };

  const renderTopSection = () => {
    return (
      <View>
        <SectionHeader
          color={Colors.white}
          title={t("HomeScreen:latestVideos")}
          onMorePress={onVideosMorePress}
          more
        />
        <Slider
          data={latestVideos}
          navigation={navigation}
          targetRoute="Video"
          titleOverImage="true"
          loadMoreURL={DataSource.latest_videos_url}
        />
      </View>
    );
  };
  return (
    <Screen
      loading={isLoading}
      error={error}
      onErrorPress={loadHomePageInfo}
      scrollable
      renderTopSection={renderTopSection}
      headerProps={{ live: false, search: true, back: false }}
      refreshControl={
        <RefreshControl
          tintColor={Colors.white}
          refreshing={isRefreshing}
          onRefresh={onRefresh}
        />
      }
    >
      <View style={{ paddingVertical: Layout.padding.xLarge }}>
        <View style={styles.newsContainer}>
          <SectionHeader
            more
            title={t("HomeScreen:latestNews")}
            onMorePress={onNewsMorePress}
          />
          <Slider
            data={latestNews}
            navigation={navigation}
            targetRoute="NewsPost"
            titleOverImage="false"
          />
        </View>
        <View style={styles.programsContainer}>
          <SectionHeader
            more
            title={t("HomeScreen:programs")}
            onMorePress={onProgramsMorePress}
          />
          <LabregahProgramsView
            onProgramPress={onProgramPress}
            latestPrograms={latestPrograms}
          />
        </View>
      </View>
    </Screen>
  );
}

export const screenOptions = ({ navigation }) => ({
  headerShown: false,
});

const styles = StyleSheet.create({
  newsContainer: {
    marginBottom: Layout.margin.large,
  },
  programsContainer: {},
});

export default HomeScreen;
