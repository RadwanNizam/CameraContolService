import React, { useState, useMemo, useEffect } from "react";
import {
  I18nManager,
  KeyboardAvoidingView,
  StyleSheet,
  View,
  Keyboard,
  TouchableWithoutFeedback,
} from "react-native";
import { Colors, Fonts, Layout, SCREEN_KEYS } from "../constants";
import PhoneInput from "../components/PhoneInput";
import TextButton from "../components/TextButton";
import { Auth } from "aws-amplify";
import useRegex from "../hooks/useRegex";
import StyledText from "../components/StyledText";

export default function LoginScreen(props) {
  const regex = useRegex();
  const [loading, setLoading] = useState(false);
  const [phoneError, setPhoneError] = useState("");
  const [phone, setPhone] = useState({
    callingCode: "974",
    cca2: "QA",
    number: "",
  });
  // const [phone, setPhone] = useState({
  //   callingCode: "970",
  //   cca2: "PS",
  //   number: "594395246",
  // });
  const number = useMemo(
    () =>
      `+${phone.callingCode}${
        phone.number.startsWith("0") ? phone.number.substring(1) : phone.number
      }`,
    [phone]
  );
  useEffect(() => {
    if (phoneError) setPhoneError("");
  }, [phone]);

  const onLoginPress = () => {
    if (!phone.number || !regex.phone(number))
      return setPhoneError("الرقم غير صالح");
    setLoading(true);
    Auth.signIn(number)
      .then((user) => {
        setLoading(false);
        props.navigation.navigate(SCREEN_KEYS.VERIFY_CODE, { user });
      })
      .catch((error) => {
        setLoading(false);
        if (error.code === "UserNotFoundException") {
          return setPhoneError("الرقم غير مسجل");
        } else if (error.code === "UsernameExistsException") {
          setPhoneError("فشلت عملية التسجيل قم بالمحاولة مرة اخرى");
        } else {
          setPhoneError("فشلت عملية التسجيل قم بالمحاولة مرة اخرى");
        }
      });
  };

  const onCreateAccountPress = () => {
    props.navigation.navigate(SCREEN_KEYS.CREATE_ACCOUNT);
  };
  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={"padding"}
        enabled={Layout.isIOS}
      >
        <View style={styles.container}>
          <StyledText children={"تسجيل الدخول"} bold size={Fonts.size.title} />
          <StyledText style={styles.subtitle} children={"سجل دخولك للمتابعة"} />
          <PhoneInput phone={phone} onChange={setPhone} error={phoneError} />
          <TextButton
            disabled={loading}
            children={"تسجيل الدخول"}
            onPress={onLoginPress}
            isLoading={loading}
            style={styles.loginButton}
          />
          <View style={styles.row}>
            <StyledText children={"ليس لديك حساب؟"} />
            <StyledText
              touchable
              onPress={onCreateAccountPress}
              containerStyle={{ padding: Layout.padding.small }}
              children={"أنشئ حساباً الأن"}
            />
          </View>
        </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.primaryColor,
    padding: Layout.padding.large,
  },
  subtitle: {
    marginTop: Layout.margin.small,
    marginBottom: Layout.margin.xLarge,
  },
  loginButton: {
    marginBottom: Layout.margin.normal,
    marginTop: Layout.margin.large,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
  },
});
