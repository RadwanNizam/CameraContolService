import React, { useEffect} from "react";
import { StyleSheet, View, ScrollView, StatusBar } from "react-native";
import { Colors, Fonts, Layout, SCREEN_KEYS } from "../constants";
import StyledText from "../components/StyledText";
import { SafeAreaView } from "react-native-safe-area-context";
import ScreenHeader from "../components/ScreenHeader";
import { t } from "../services/i18n";
import {getLabregahProgram, getLoadMoreURL} from "../utils/Programs"
import {PROGRAM_WINNERS, PROGRAM_YARDS, PROGRAM_EZPATY,PROGRAM_STARS} from '../store/actions/homeActions';
import { useSelector } from "react-redux";
const Section = (props) => {
  return (
    <View>
      <StyledText
        bold
        size={Fonts.size.large}
        color={Colors.gray}
        children={props.title}
      />
      {props.data.map((item, index) => {
        return (
          <StyledText
            color={Colors.gray}
            key={index}
            touchable
            size={Fonts.size.normal}
            onPress={item.onPress}
            children={item.title}
            style={{paddingVertical: 2}}
          />
        );
      })}
    </View>
  );
};

export default function MoreScreen({navigation, route}) {
  const latestPrograms = useSelector((state) => state.home.latestPrograms);

  const programs = [
    { title: t("common:ezpaty"), onPress: () => navigation.navigate(SCREEN_KEYS.VIDEO, 
      {post: getLabregahProgram(PROGRAM_EZPATY, latestPrograms), videoURL: getLoadMoreURL(PROGRAM_EZPATY)})},

    { title: t("common:winners"), onPress: () => navigation.navigate(SCREEN_KEYS.VIDEO, 
      {post: getLabregahProgram(PROGRAM_WINNERS, latestPrograms), videoURL: getLoadMoreURL(PROGRAM_WINNERS)})},

    { title: t("common:labregah_yeard"), onPress: () => navigation.navigate(SCREEN_KEYS.VIDEO, 
      {post: getLabregahProgram(PROGRAM_YARDS, latestPrograms), videoURL: getLoadMoreURL(PROGRAM_YARDS)})},

    { title: t("common:labregah_stars"), onPress: () => navigation.navigate(SCREEN_KEYS.VIDEO, 
     {post: getLabregahProgram(PROGRAM_STARS, latestPrograms), videoURL: getLoadMoreURL(PROGRAM_STARS)})},
  ];
  const races = [
    { title: t("RacingVideosScreen:title"), onPress: () => navigation.navigate(SCREEN_KEYS.RACING_VIDEOS) },
    { title: t("RacingResultsScreen:title"), onPress: () => navigation.navigate(SCREEN_KEYS.RACING_RESULTS) },
    { title: t("RacingDatesScreen:title"), onPress: () => navigation.navigate(SCREEN_KEYS.RACING_DATES) }
  ];
  useEffect(() => {
    const unsubscribeFocus = navigation.addListener('focus', () => {
      StatusBar.setBarStyle('dark-content')
    });
    const unsubscribeBlur = navigation.addListener('blur', () => {
      StatusBar.setBarStyle('light-content')
    });
    return () => {
      unsubscribeFocus()
      unsubscribeBlur();
    };
  }, []);
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle={'dark-content'} />
      <ScreenHeader title={t("common:more")} color={Colors.gray} back={false}/>
      <ScrollView>
        <Section title={t("common:programs")} data={programs} />
        <Section title={t("common:races")} data={races} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    paddingHorizontal: Layout.padding.content,
  },
});
