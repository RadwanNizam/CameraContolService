import React from 'react';
import {View, Text, StyleSheet, ScrollView, Image} from 'react-native';
import {POSTS} from '../data/data'
import { t,isRTL } from '../services/i18n';
import {WebView} from 'react-native-webview';
import Screen from "./Screen";

function NewsPostScreen ({ route, navigation }) {
    const { post } = route.params;
    //const selectedPost = POSTS.find(post => post.id === itemId);
    //"https://wordpress.org/news/wp-json/wp/v2/posts/8571"
  //  let articleURL = 'http://labregah.net/portal/index.php?option=com_content&view=article&id=2627:%D8%AA%D8%B5%D8%B1%D9%8A%D8%AD%D8%A7%D8%AA-%D9%85%D8%AC%D9%85%D8%B9%D8%A9-%D9%84%D9%84%D9%85%D8%AA%D9%88%D8%AC%D9%8A%D9%86-%D8%A8%D8%B1%D9%85%D9%88%D8%B2-%D8%A7%D9%84%D8%AD%D9%82%D8%A7%D9%8A%D9%82-%D8%A7%D9%84%D8%B0%D9%87%D8%A8%D9%8A%D8%A9-%D9%88%D8%A7%D9%84%D9%81%D8%B6%D9%8A%D8%A9-%D8%A8%D9%85%D9%87%D8%B1%D8%AC%D8%A7%D9%86-%D8%A7%D9%84%D8%A3%D9%85%D9%8A%D8%B1-%D8%A7%D9%84%D9%88%D8%A7%D9%84%D8%AF&catid=9&Itemid=212';

    const renderItems = props => {
        var items = [];
        // var selectedPost = props.post;
        items.push(<Text style={styles.title}>{post.title}</Text>);
        items.push(<View style={styles.imageContainer}><Image source={{uri: post.featuredImgUrl}} style={styles.image} /></View>);
        // items.push(<Text style={styles.text}>{selectedPost.text}</Text>);

        return items;
    }


    return (
        // <View style={styles.screen}>
        <Screen
        // loading={loading}
        // error={error}
        // onErrorPress={loadMoreVideos}
        // scrollableContent
        // renderTopSection={renderTopSection}
        headerProps={{ live: false, search: true }}
        title={t('NewsPostScreen:screenTitle')}
        scrollableContent={false}
      >
        <WebView
        source={{ uri: post.url ? post.url + '&mobile_app=true' : null}}
        //  scalesPageToFit="true"  
        />
        </Screen>
    );
};

export const screenOptions = ({ navigation }) => ({    
    headerShown: false,
});

// uri: 'http://13.126.168.210/news/%d8%a5%d8%ac%d8%a7%d8%b2%d8%a9-%d8%b9%d9%8a%d8%af-%d8%a7%d9%84%d8%a3%d8%b6%d8%ad%d9%89/' 

const styles = StyleSheet.create({
    screen:{
        flex: 1,
        alignItems: 'center',
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignItems: 'stretch',
        paddingStart: 10,
        paddingEnd: 10,
        paddingTop: 10
    },
    imageContainer:{
        paddingTop: 10
    },
    image: {
        width: '100%',
        aspectRatio: 16 / 9,
        paddingTop: 10
    },
    title:{
        fontFamily: 'cairo-bold',
        fontSize: 14,
        textAlign: 'center'
    },
    text:{
        fontFamily: 'cairo-light',
        fontSize: 14,
        writingDirection: isRTL ? 'rtl':'ltr',
    }
});
export default NewsPostScreen;