import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Button,
  StyleSheet,
  ActivityIndicator,
  Dimensions,
  Image,
  FlatList,
} from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import { SafeAreaView } from "react-native-safe-area-context";
import GenericPost from "../components/GenericPost";
import ItemsList from "../components/ItemsList";
import Colors from "../constants/Colors";
import DataSource from "../constants/DataSource";
import { POSTS } from "../data/data";
import { t } from "../services/i18n";
import Screen from "./Screen";
import { wpArticleToAppNewsPost } from "../utils/WPPostConverter";
import moment from "moment";
import useRefresh from "../hooks/useRefresh";
import { getAuthToken } from "../utils/Security";
import { handleFetchErrors } from "../utils/FetchData";
import { Alert } from "react-native";

function NewsScreen({ route, navigation }) {
  const [latestNews, setLatestNews] = useState([]);
  const [loading, setLoading] = useState(true);
  // const [pageNumber, setPageNumber] = useState(1);
  const [error, setError] = useState();
  const [isRefreshing, setIsRefreshing] = useState(false);

  function fetchFirstPage() {
    let url = DataSource.latest_news_url;
    // let token = await getAuthToken();

    fetchPage(url, 0);
  }

  /**
   * @param fetchLatest : If true, the method fetch the latest news (published after the first element in the array 'news').
   * if false, fetches the news before the last element in the array 'news'.
   */
  function fetchNews(fetchLatest) {
    setLoading(true);
    // let token = await getAuthToken();
    let url = DataSource.latest_news_url;
    let originalMomentLocale = moment.locale();
    let resultAppendMode = 0;
    moment.locale("en");

    if (fetchLatest) {
      let firstPostDate = latestNews.length > 0 ? latestNews[0].date : null;
      url +=
        firstPostDate != null
          ? "?after=" + moment(firstPostDate).format("yyyy-MM-DDTHH:mm:ss")
          : "";
      resultAppendMode = 1;
    } else {
      let lastPostDate =
        latestNews.length > 0 ? latestNews[latestNews.length - 1].date : null;
      url +=
        lastPostDate != null
          ? "?before=" + moment(lastPostDate).format("yyyy-MM-DDTHH:mm:ss")
          : "";
      resultAppendMode = 2;
    }

    moment.locale(originalMomentLocale);
    fetchPage(url, resultAppendMode);
  }

  /**
   * Load more news using the provided URL and append the result to the array news according to resultAppendMode
   * @param {*} url The URL to load news
   * @param {*} resultAppendMode
   *  0 clear previous results and return the retreived news only
   *  1 add the results to the top of the array news
   *  2 add the results to the end of the array news
   */
  async function fetchPage(url, resultAppendMode) {
    // console.log('token', await token());
    let authToken = await getAuthToken();
    setLoading(true);
    fetch(url, {
      method: "GET",
      headers: new Headers({
        Authorization: authToken,
      }),
    })
      .then((response) => response.json())
      .then((json) => {
        if (Array.isArray(json) && json.length > 0) {
          let latest = [];
          json.map((post) => {
            latest.push(wpArticleToAppNewsPost(post));
          });

          if (resultAppendMode == 0) {
            setLatestNews(latest);
          } else if (resultAppendMode == 1) {
            setLatestNews([...latest, ...latestNews]);
          } else {
            setLatestNews([...latestNews, ...latest]);
          }
        }
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        handleFetchErrors(error)
      })
      .finally(() => {
        setLoading(false);
        setIsRefreshing(false);
      });
  }

  const refreshData = () => {
    fetchFirstPage();
  };

  const { resetLastRefreshDate } = useRefresh(refreshData);

  const renderFooter = () => {
    if (loading) {
      return (
        <View style={{ flex: 1, padding: 24 }}>
          <ActivityIndicator color={Colors.primaryColor} />
        </View>
      );
    } else {
      return <View />;
    }
  };

  const renderItem = ({ item }) => {
    return (
      <TouchableOpacity
        onPress={() => navigation.navigate("NewsPost", { post: item })}
      >
        <GenericPost post={item} />
      </TouchableOpacity>
    );
  };

  useEffect(() => {
    if (latestNews.length === 0) {
      fetchNews(true);
    }
    resetLastRefreshDate();
  }, []);

  return (
    <Screen
      // loading={loading}
      error={error}
      onErrorPress={() => {
        fetchNews(true);
      }}
      // scrollableContent
      // renderTopSection={renderTopSection}
      headerProps={{ live: false, search: true, back: false }}
      title={t("NewsScreen:latestNews")}
    >
      <View style={styles.mainContainer}>
        <FlatList
          data={latestNews}
          renderItem={(item) => renderItem(item)}
          numColumns={1}
          onRefresh={() => {
            setIsRefreshing(true);
            fetchNews(true);
          }}
          keyExtractor={(post, index) => post.id.toString()}
          scrollEnabled={true}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={renderFooter}
          onEndReached={() => {
            fetchNews(false);
          }}
          refreshing={isRefreshing}
        />
      </View>
      {/* </View> */}
    </Screen>
  );
}

export const screenOptions = ({ navigation }) => ({
  // headerTitle: () =>
  //     <SafeAreaView >
  //         <View width={Dimensions.get('window').width * 80 / 100} style={{ display: 'flex', flexDirection: "row", justifyContent: "space-between" }}>
  //             <Image source={require('../assets/search.png')} />
  //             <Text style={styles.screenTitle}>{t('NewsScreen:latestNews')}</Text>
  //             {/* <Image source={require('../assets/back.png')} />
  //          */}
  //             <Text style={styles.screenTitle}> </Text>
  //         </View>
  //     </SafeAreaView>
  headerShown: false,
});

const styles = StyleSheet.create({
  screen: {
    // flex: 1,
    // alignItems: 'center',
    // flexDirection: 'column',
    // justifyContent: 'flex-start',
    // alignItems: 'stretch',
    // paddingStart: 10,
    // paddingEnd: 10,
    // paddingTop: 10,
    // borderRadius: 40,

    flex: 1,
    alignItems: "center",
    // width: '100%',
    flexDirection: "column",
    justifyContent: "flex-start",
    alignItems: "stretch",
    // paddingStart: 10,
    // paddingEnd: 10,
    paddingTop: 10,
    backgroundColor: Colors.primaryColor,
  },
  mainContainer: {
    alignItems: "center",
    width: "100%",
    flexDirection: "column",
    justifyContent: "flex-start",
    alignItems: "stretch",
    borderTopStartRadius: 30,
    borderTopEndRadius: 30,
    backgroundColor: Colors.secondaryColor,
    flex: 1,
    flexDirection: "column",
    paddingStart: 10,
    paddingEnd: 10,
    paddingTop: 10,
  },
  screenTitle: {
    fontFamily: "cairo-bold",
    fontSize: 21,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0,
    color: Colors.fontColor1,
  },
});

export default NewsScreen;
