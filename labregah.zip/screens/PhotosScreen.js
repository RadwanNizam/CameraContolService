import React from 'react';
import {View, Text, StyleSheet} from 'react-native';


function PhotosScreen ({ route, navigation }) {
    return (    
        <View><Text>Photos Screen</Text></View>    
    );
};

export const screenOptions = ({ navigation }) => ({    
    title: 'Photos Screen'
});


const styles = StyleSheet.create({
    screen:{
    }
});

export default PhotosScreen;