import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet, ActivityIndicator, Dimensions, Image } from 'react-native';
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useSelector } from 'react-redux';
import GenericPost from '../components/GenericPost';
import Colors from '../constants/Colors';
import DataSource from '../constants/DataSource';
import { t, } from '../services/i18n';
import {PROGRAM_WINNERS, PROGRAM_YARDS, PROGRAM_EZPATY,PROGRAM_STARS} from '../store/actions/homeActions';
import Screen from "./Screen";
import {getLabregahProgram, getLoadMoreURL} from "../utils/Programs"
function ProgramsScreen({ route, navigation }) {

  const latestPrograms = useSelector((state) => state.home.latestPrograms);

  const renderItem = ({ item }) => {
    return <TouchableOpacity
      onPress={() => navigation.navigate('Video', {post:  getLabregahProgram(item.postType, latestPrograms), 
        videoURL: getLoadMoreURL(item.postType)})}>
      <GenericPost post={item} navigation={navigation} targetRoute='Video' />
    </TouchableOpacity>
  };

  return (
    <Screen
    scrollableContent
    headerProps={{ live: false, search: true }}
    title={t('common:programs')}
    scrollableContent={false}
  >
        <View style={styles.mainContainer}>         
            <FlatList
              data={latestPrograms}
              renderItem={(item) => renderItem(item)}
              numColumns={1}
              keyExtractor={(post, index) => String(index)}
              scrollEnabled={true}
              showsVerticalScrollIndicator={false}
            />
        </View>
  </Screen>
  );
};

export const screenOptions = ({ navigation, route }) => ({
  headerShown: false
  // headerTitle: () => {
  //   let titleKey = 'common:programs';
  //   return <SafeAreaView >
  //     <View width={Dimensions.get('window').width * 80 / 100} style={{ display: 'flex', flexDirection: "row", justifyContent: "space-between" }}>
  //       <Image source={require('../assets/search.png')} />
  //       <Text style={styles.screenTitle}>{t(titleKey)}</Text>
  //       {/* <Image source={require('../assets/back.png')} /> */}
  //       <Text style={styles.screenTitle}></Text>
  //     </View>
  //   </SafeAreaView>
  // }
});

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    paddingTop: 10,
    backgroundColor: Colors.primaryColor
  }, mainContainer: {
    alignItems: 'center',
    width: '100%',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    borderTopStartRadius: 30,
    borderTopEndRadius: 30,
    backgroundColor: Colors.secondaryColor,
    flex: 1,
    flexDirection: "column",
    paddingStart: 10,
    paddingEnd: 10,
    paddingTop: 10
  },
  screenTitle: {
    fontFamily: "cairo-bold",
    fontSize: 21,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0,
    color: Colors.fontColor1
  },
  btnText: {
    color: 'white',
    fontSize: 15,
    textAlign: 'center',
  },
});

export default ProgramsScreen;