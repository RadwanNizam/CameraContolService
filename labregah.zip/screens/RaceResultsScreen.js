import React, { useCallback, useEffect, useState, useMemo, useRef } from "react";
import { View, StyleSheet, ActivityIndicator, TextInput,Modal } from "react-native";
import { FlatList } from "react-native-gesture-handler";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useDispatch, useSelector } from "react-redux";
import { t } from "../services/i18n";
import ErrorHandler from "../components/ErrorHandler";
import ScreenHeader from "../components/ScreenHeader";
import { LinearGradient } from "expo-linear-gradient";
import StyledText from "../components/StyledText";
import {  Layout, Styles, Colors } from "../constants";
import { Ionicons } from "@expo/vector-icons";
import { fetchRaceResults } from "../store/actions/racingResultsActions";
import RaceResult from "../components/RaceResult";
import RaceResultsFilter from "../components/RaceResultsFilter";
import { Text } from "react-native";

import VideoPlayer from "../components/VideoPlayer";
function RaceResultsScreen({ route, navigation }) {
  const [isLoading, setIsLoading] = useState(false);
  const [filterVisible, setFilterVisible] = useState(true);
  const [error, setError] = useState();
  const insets = useSafeAreaInsets();
  const [searchText, setSearchText] = useState("");
  const [selectedFilters, setSelectedFilters] = useState({});
  const dispatch = useDispatch();
  const { id } = route?.params;
  const results = useSelector((state) => state.racingResults.raceResults);
  const [showVideo, setShowVideo] = useState(false);

  const playerRef = useRef(null);

  const filters = useMemo(() => {
    if (results?.[0]?.old_response) return null;
    const fields = new Set();
    const days = new Set();
    const categories = new Set();
    const periods = new Set();
    const invitations = new Set();
    const classes = new Set();
    results.forEach((item) => {
      if (item["field"]) fields.add(item["field"]);
      if (item["day"]) days.add(item["day"]);
      if (item["category"]) categories.add(item["category"]);
      if (item["period"]) periods.add(item["period"]);
      if (item["invitation"]) invitations.add(item["invitation"]);
      if (item["class"]) classes.add(item["class"]);
    });
    return {
      fields: Array.from(fields),
      days: Array.from(days),
      categories: Array.from(categories),
      periods: Array.from(periods),
      invitations: Array.from(invitations),
      classes: Array.from(classes),
    };
  }, [results]);

  const filter = (item) => {
    const titleCondition = item["إسم_المطية"]
      .toLowerCase()
      .includes(searchText?.toLowerCase() || "");
    if (!filters) return titleCondition;

    const filtersCondition = Object.keys(selectedFilters).reduce(
      (accumulator, currentValue) => {
        return (
          accumulator &&
          (!selectedFilters[currentValue] ||
            item[currentValue] == selectedFilters[currentValue])
        );
      },
      true
    );
    return titleCondition && filtersCondition;
  };

  const filtered = useMemo(() => results.filter(filter), [
    results,
    searchText,
    selectedFilters,
  ]);

  const fetchResults = useCallback(async () => {
    setError(null);
    setIsLoading(true);
    try {
      await dispatch(fetchRaceResults(id));
    } catch (err) {
      setError(err.message);
    }
    setIsLoading(false);
  }, [id]);

  useEffect(() => {
    fetchResults();
  }, []);
  if (error) {
    return <ErrorHandler onPress={fetchResults} error={error} />;
  }

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator color={Colors.white} />
      </View>
    );
  }

  const keyExtractor = (item) => item.index;
  const renderItem = ({ item }) => {
    return <RaceResult item={item} navigation={navigation} showVideo={onVideoPress}/>;
  };
  const onFilterPress = () => {
    setFilterVisible(true);
  };

  const onVideoPress = () =>{
    setShowVideo(true);
  }

  // renderVideoPlayer(){
  //   if (showVideo){
  //     return <View><Modal><Text>Hello</Text></Modal></View>
  //   }else{
  //     return <View></View>
  //   }
  // }

  const viewVideoPlayer = () =>{
    setShowVideo(true);
  }
  return (
    <View style={styles.screen}>
     
      <LinearGradient
        style={{ flex: 1, paddingTop: insets.top }}
        colors={Colors.gradient}
      >


        <ScreenHeader
          title={t("RaceResultsScreen:title")}
          filter={!!filters}
          onFilterPress={onFilterPress}
        />

        <RaceResultsFilter
          visible={filterVisible}
          setVisible={setFilterVisible}
          onSearch={setSelectedFilters}
          {...filters}
        />

        <VideoPlayer
          visible={showVideo}
          setVisible={setShowVideo}
        />

        <View style={styles.contentContainer}>
          <View style={styles.searchInputContainer}>
            <Ionicons name="md-search" size={24} color={Colors.fontColor3} />
            <TextInput
              value={searchText}
              onChangeText={setSearchText}
              placeholder={t("common:searchInResult")}
              style={{ padding: Layout.padding.normal }}
            />
          </View>
          

          <FlatList
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContainer}
            data={filtered}
            keyExtractor={keyExtractor}
            renderItem={renderItem}
            removeClippedSubviews={true}
            initialNumToRender={10}
            ListEmptyComponent={
              <StyledText
                bold
                center
                color={Colors.gray}
                children={t("RaceResultsScreen:empty")}
              />
            }
          />
        </View>
      </LinearGradient>

              {/* <View style={styles.overlay}>

                <YoutubePlayer
                          ref={playerRef}
                          height={300}
                          width="100%"
                          videoId="h6lB0RybYWo"
                          play={true}
                          // onChangeState={event => console.log(event)}
                          // onReady={() => console.log("ready")}
                          // onError={e => console.log(e)}
                          onPlaybackQualityChange={q => console.log(q)}
                          volume={50}
                          playbackRate={1}
                          playerParams={{
                            cc_lang_pref: "us",
                            showClosedCaptions: true
                          }}
                        />
              </View> */}

            
    </View>
  );
}

export const screenOptions = ({ navigation }) => ({
  headerShown: false,
});

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: Colors.primaryColor,
  },
  contentContainer: {
    flex: 1,
    backgroundColor: Colors.white,
    borderTopLeftRadius: Layout.radius.xxxLarge,
    borderTopRightRadius: Layout.radius.xxxLarge,
  },
  searchInputContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: Layout.padding.normal,
    marginHorizontal: Layout.margin.content,
    borderBottomColor: Colors.lightGray,
    borderBottomWidth: 2,
    marginTop: Layout.margin.normal,
  },
  listContainer: {
    paddingHorizontal: Layout.padding.content,
    paddingVertical: Layout.padding.normal,
  },
  overlay: {
    flex: 1,
    position: 'absolute',
    right: 0,
    top: 20,
    opacity: 0.9,
    backgroundColor: 'black',
    width: 400,
     height: 650
  } 
});

export default RaceResultsScreen;
