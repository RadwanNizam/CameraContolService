import React, { useCallback, useEffect, useState, useMemo } from "react";
import { View, StyleSheet, ActivityIndicator, TextInput } from "react-native";
import { FlatList } from "react-native-gesture-handler";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useDispatch, useSelector } from "react-redux";
import { t } from "../services/i18n";
import ErrorHandler from "../components/ErrorHandler";
import ScreenHeader from "../components/ScreenHeader";
import { LinearGradient } from "expo-linear-gradient";
import StyledText from "../components/StyledText";
import { Fonts, Layout, Styles, Colors } from "../constants";
import { Ionicons } from "@expo/vector-icons";
import { fetchRaceVideos } from "../store/actions/racingVideosActions";
import RaceVideo from "../components/RaceVideo";
import RaceVideosFilter from "../components/RaceVideosFilter";

function RaceVideosScreen({ route, navigation }) {
  const [isLoading, setIsLoading] = useState(false);
  const [filterVisible, setFilterVisible] = useState(false);
  const [error, setError] = useState();
  const insets = useSafeAreaInsets();
  const [searchText, setSearchText] = useState("");
  const [selectedFilters, setSelectedFilters] = useState({});
  const dispatch = useDispatch();
  const { id } = route?.params;
  const videos = useSelector((state) => state.racingVideos.raceVideos);

  const filters = useMemo(() => {
    if (videos?.[0]?.old_response) return null;
    const fields = new Set();
    const days = new Set();
    const categories = new Set();
    const periods = new Set();
    const invitations = new Set();
    videos.forEach((item) => {
      if (item["field"]) fields.add(item["field"]);
      if (item["day"]) days.add(item["day"]);
      if (item["category"]) categories.add(item["category"]);
      if (item["period"]) periods.add(item["period"]);
      if (item["invitation"]) invitations.add(item["invitation"]);
    });
    return {
      fields: Array.from(fields),
      days: Array.from(days),
      categories: Array.from(categories),
      periods: Array.from(periods),
      invitations: Array.from(invitations),
    };
  }, [videos]);

  const filter = (item) => {
    const titleCondition = item["video_title"]
      .toLowerCase()
      .includes(searchText?.toLowerCase() || "");
    if (!filters) return titleCondition;

    const filtersCondition = Object.keys(selectedFilters).reduce(
      (accumulator, currentValue) => {
        return (
          accumulator &&
          (!selectedFilters[currentValue] ||
            item[currentValue] == selectedFilters[currentValue])
        );
      },
      true
    );
    return titleCondition && filtersCondition;
  };

  const filtered = useMemo(() => videos.filter(filter), [
    videos,
    searchText,
    selectedFilters,
  ]);

  const fetchVideos = useCallback(async () => {
    setError(null);
    setIsLoading(true);
    try {
      await dispatch(fetchRaceVideos(id));
    } catch (err) {
      setError(err.message);
    }
    setIsLoading(false);
  }, [id]);

  useEffect(() => {
    fetchVideos();
  }, []);
  if (error) {
    return <ErrorHandler onPress={fetchVideos} error={error} />;
  }

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator color={Colors.white} />
      </View>
    );
  }

  const keyExtractor = (item) => item.index;
  const renderItem = ({ item, index }) => {
    return <RaceVideo item={item} index={index} navigation={navigation} />;
  };

  const onFilterPress = () => {
    setFilterVisible(true);
  };
  return (
    <View style={styles.screen}>
      <LinearGradient
        style={{ flex: 1, paddingTop: insets.top }}
        colors={Colors.gradient}
      >
        <ScreenHeader
          title={t("RaceVideosScreen:title")}
          filter={!!filters}
          onFilterPress={onFilterPress}
        />
        <RaceVideosFilter
          visible={filterVisible}
          setVisible={setFilterVisible}
          onSearch={setSelectedFilters}
          {...filters}
        />
        <View style={styles.contentContainer}>
          <View style={styles.searchInputContainer}>
            <Ionicons name="md-search" size={24} color={Colors.fontColor3} />
            <TextInput
              value={searchText}
              onChangeText={setSearchText}
              placeholder={t("common:searchInResult")}
              style={{ padding: Layout.padding.normal }}
            />
          </View>
          <FlatList
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContainer}
            data={filtered}
            keyExtractor={keyExtractor}
            renderItem={renderItem}
            removeClippedSubviews={true}
            initialNumToRender={10}
            ListEmptyComponent={
              <StyledText
                bold
                center
                color={Colors.gray}
                children={t("RaceVideosScreen:empty")}
              />
            }
          />
        </View>
      </LinearGradient>
    </View>
  );
}

export const screenOptions = ({ navigation }) => ({
  headerShown: false
});

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: Colors.primaryColor,
  },
  contentContainer: {
    flex: 1,
    backgroundColor: Colors.white,
    borderTopLeftRadius: Layout.radius.xxxLarge,
    borderTopRightRadius: Layout.radius.xxxLarge,
  },
  searchInputContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: Layout.padding.normal,
    marginHorizontal: Layout.margin.content,
    borderBottomColor: Colors.lightGray,
    borderBottomWidth: 2,
    marginTop: Layout.margin.normal,
  },
  listContainer: {
    paddingHorizontal: Layout.padding.content,
    paddingVertical: Layout.padding.normal,
  },
});

export default RaceVideosScreen;
