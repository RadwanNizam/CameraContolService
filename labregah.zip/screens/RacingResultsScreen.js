import React, { useCallback, useEffect, useState } from "react";
import {
  View,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useDispatch, useSelector } from "react-redux";
import Colors from "../constants/Colors";
import { t } from "../services/i18n";
import {
  fetchCountries,
  fetchSeasons,
  fetchFestivals,
  searchRacingResults,
  clearResults,
  clearSeasons,
  clearFestivals,
  clearCountries,
} from "../store/actions/racingResultsActions";
import ErrorHandler from "../components/ErrorHandler";
import ScreenHeader from "../components/ScreenHeader";
import { LinearGradient } from "expo-linear-gradient";
import StyledText from "../components/StyledText";
import { Fonts, Layout, SCREEN_KEYS } from "../constants";
import PickerButton from "../components/PickerButton";
import Race from "../components/Race";
import useRefresh from "../hooks/useRefresh";

function RacingResultsScreen({ route, navigation }) {
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingSeasons, setIsLoadingSeasons] = useState(false);
  const [isLoadingFestivals, setIsLoadingFestivals] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState();
  const [selectedCountry, setSelectedCountry] = useState();
  const [selectedSeason, setSelectedSeason] = useState();
  const [seasonName, setSeasonName] = useState("");
  const [selectedFestival, setSelectedFestival] = useState();
  const [festivalName, setFestivalName] = useState("");
  const insets = useSafeAreaInsets();
  const dispatch = useDispatch();
  const countries = useSelector((state) => state.racingResults.countries);
  const seasons = useSelector((state) => state.racingResults.seasons);
  const festivals = useSelector((state) => state.racingResults.festivals);
  const searchResult = useSelector((state) => state.racingResults.searchResult);

  const loadRacingVideosInfo = useCallback(async () => {
    setError(null);
    setIsLoading(true);
    try {
      await dispatch(fetchCountries());
    } catch (err) {
      console.log(err);
      setError(err.message);
    }
    setIsLoading(false);
  }, [dispatch, setIsLoading, setError]);

  useEffect(() => {
    loadRacingVideosInfo();
  }, [dispatch, loadRacingVideosInfo]); // will run only when the component is loaded

  const handleSearch = async () => {
    if (selectedCountry != null && selectedSeason != null) {
      setIsSearching(true);
      try {
        await dispatch(
          searchRacingResults(selectedCountry, selectedSeason, selectedFestival)
        );
      } catch (error) {}
      setIsSearching(false);
    }
  };
  const loadSeasons = async () => {
    setIsLoadingSeasons(true);
    try {
      await dispatch(fetchSeasons(selectedCountry));
    } catch (error) {}
    setIsLoadingSeasons(false);
  };
  useEffect(() => {
    if (selectedCountry) {
      loadSeasons();
    }
    setSelectedSeason(null);
    setSelectedFestival(null);
    setFestivalName("");
    setSeasonName("");
    dispatch(clearSeasons())
    dispatch(clearFestivals())
  }, [selectedCountry]);

  const onCountryPress = (id) => {
    dispatch(clearResults());
    setSelectedCountry(id);
  };
  const onSeasonPress = async ({ id, name }) => {
    dispatch(clearResults());
    setSelectedSeason(id);
    setSeasonName(name);
    setSelectedFestival(null);
    setFestivalName("");
    dispatch(clearFestivals())
    try {
      setIsLoadingFestivals(true);
      await dispatch(fetchFestivals(selectedCountry, id));
    } catch (error) {}
    setIsLoadingFestivals(false);
  };

  const onFestivalPress = ({ id, name }) => {
    setSelectedFestival(id);
    setFestivalName(name);
  };
  useEffect(() => {
    handleSearch();
  }, [selectedSeason, selectedFestival]);
  useEffect(() => {
    if (countries.length) {
      onCountryPress(countries[0].id);
    }
  }, [countries]);
  const refreshData = async () => {
    dispatch(clearCountries())
    setIsLoading(true)
    setSelectedCountry(null)
    try {
      await dispatch(fetchCountries());
    } catch (error) {}
    if (countries.length) {
      onCountryPress(countries[0].id);
    }
    setIsLoading(false)
  };
  const { resetLastRefreshDate } = useRefresh(refreshData);

  if (error) {
    return <ErrorHandler onPress={loadRacingVideosInfo} error={error} />;
  }

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator color={Colors.white} />
      </View>
    );
  }

  const countryKeyExtractor = (item) => item.id.toString();
  const renderCountry = ({ item }) => {
    const isSelected = item.id == selectedCountry;
    const onPress = () => {
      onCountryPress(item.id);
    };
    return (
      <StyledText
        bold={isSelected}
        containerStyle={[styles.country, isSelected && styles.selectedCountry]}
        touchable
        onPress={onPress}
        children={item.name}
      />
    );
  };
  const raceKeyExtractor = (item) => item.id.toString();
  const renderRace = ({ item }) => {
    const onPress = () => {
      navigation.navigate(SCREEN_KEYS.RACE_RESULTS, { id: item.id });
    };
    return (
      <Race
        {...item}
        countries={countries}
        seasons={seasons}
        onPress={onPress}
      />
    );
  };
  return (
    <View style={styles.screen}>
      <LinearGradient
        style={{ flex: 1, paddingTop: insets.top }}
        colors={Colors.gradient}
      >
        <ScreenHeader
          style={{ marginBottom: 0 }}
          title={t("RacingResultsScreen:title")}
        />
        <View style={{alignItems: 'flex-start'}}>
          <FlatList
            horizontal
            contentContainerStyle={{
              paddingHorizontal: Layout.padding.content,
            }}
            showsHorizontalScrollIndicator={false}
            data={countries}
            keyExtractor={countryKeyExtractor}
            renderItem={renderCountry}
          />
        </View>
        <View style={styles.pickersContainer}>
          <PickerButton
            title={t("RacingResultsScreen:chooseSeason")}
            value={seasonName}
            placehoolder={t("RacingResultsScreen:season")}
            selected={selectedSeason}
            data={seasons}
            onSelect={onSeasonPress}
            style={styles.seasonButton}
            isLoading={isLoadingSeasons}
          />
          <PickerButton
            disabled={!selectedSeason}
            title={t("RacingResultsScreen:chooseFestival")}
            value={festivalName}
            placehoolder={t("RacingResultsScreen:festival")}
            selected={selectedFestival}
            data={festivals}
            onSelect={onFestivalPress}
            style={[styles.festivalButton, !selectedSeason && { opacity: 0.6 }]}
            isLoading={isLoadingFestivals}
          />
        </View>

        {/* <StyledText
          bold
          rounded
          touchable
          containerStyle={styles.searchButton}
          color={Colors.gray}
          children={t("common:search")}
          onPress={handleSearch}
        /> */}
        <View style={styles.contentContainer}>
          <FlatList
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              paddingHorizontal: Layout.padding.content,
              paddingVertical: Layout.padding.xLarge,
            }}
            data={searchResult}
            keyExtractor={raceKeyExtractor}
            renderItem={renderRace}
            ListEmptyComponent={
              isSearching ? (
                <ActivityIndicator color={Colors.primaryColor} />
              ) : (
                <StyledText
                  bold
                  center
                  color={Colors.gray}
                  children={
                    selectedSeason
                      ? t("RacingResultsScreen:empty")
                      : t("RacingResultsScreen:chooseSeason")
                  }
                />
              )
            }
          />
        </View>
      </LinearGradient>
    </View>
  );
}

export const screenOptions = ({ navigation }) => ({
  headerShown: false,
});

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: Colors.primaryColor,
  },
  country: {
    paddingHorizontal: Layout.padding.medium,
    paddingVertical: Layout.padding.small,
  },
  selectedCountry: {
    borderColor: Colors.white,
    borderBottomWidth: 1,
  },
  pickersContainer: {
    width: "100%",
    flexDirection: "row",
    paddingHorizontal: Layout.padding.content,
    marginVertical: Layout.margin.normal,
  },
  searchButton: {
    alignSelf: "center",
    backgroundColor: Colors.white,
    marginVertical: Layout.margin.normal,
  },
  contentContainer: {
    flex: 1,
    backgroundColor: Colors.white,
    borderTopLeftRadius: Layout.radius.xxxLarge,
    borderTopRightRadius: Layout.radius.xxxLarge,
  },
  seasonButton: { marginRight: Layout.margin.small },
  festivalButton: { marginLeft: Layout.margin.small },
});

export default RacingResultsScreen;
