import React from 'react';
import {View, Text, StyleSheet} from 'react-native';


function ResultsScreen ({ route, navigation }) {
    return (    
        <View><Text>Results Screen</Text></View>    
    );
};

export const screenOptions = ({ navigation }) => ({    
    title: 'Results Screen'
});


const styles = StyleSheet.create({
    screen:{
    }
});

export default ResultsScreen;