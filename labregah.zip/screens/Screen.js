import React, { useCallback, useEffect, useState } from "react";
import { View, StyleSheet, ActivityIndicator } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Colors from "../constants/Colors";
import ErrorHandler from "../components/ErrorHandler";
import ScreenHeader from "../components/ScreenHeader";
import { LinearGradient } from "expo-linear-gradient";
import { Fonts, Layout, SCREEN_KEYS } from "../constants";
import PropTypes from "prop-types";
import { ScrollView } from "react-native";
import { ViewPropTypes } from "react-native";
import { RefreshControl } from "react-native";

const ScreenContainer = (props) => {
  const insets = useSafeAreaInsets();
  return (
    <View style={styles.screen}>
      <LinearGradient
        style={[{ flex: 1, paddingTop: insets.top }, props.style]}
        colors={Colors.gradient}
      >
        {props.children}
      </LinearGradient>
    </View>
  );
};
const Loader = () => {
  return (
    <ScreenContainer style={{ justifyContent: "center" }}>
      <ActivityIndicator color={Colors.white} size={"large"} />
    </ScreenContainer>
  );
};

const Scrollable = ({ enabled, refreshControl, ...props }) => {
  const [isEndReached, setisEndReached] = useState(false);
  const onScroll = (e) => {
    if (
      e.nativeEvent.contentOffset.y >=
      e.nativeEvent.contentSize.height - e.nativeEvent.layoutMeasurement.height
    ) {
      if (!isEndReached) setisEndReached(true);
    } else {
      if (isEndReached) setisEndReached(false);
    }
  };
  return enabled ? (
    <ScrollView
      onScroll={onScroll}
      scrollEventThrottle={10}
      bounces={!isEndReached}
      contentContainerStyle={{ flexGrow: 1 }}
      showsVerticalScrollIndicator={false}
      refreshControl={refreshControl}
      {...props}
    />
  ) : (
    <React.Fragment {...props} />
  );
};
export default function Screen(props) {
  if (props.loading) {
    return <Loader />;
  }
  if (props.error) {
    return <ErrorHandler onPress={props.onErrorPress} error={props.error} />;
  }
  return (
    <ScreenContainer>
      <ScreenHeader title={props.title} {...props.headerProps} />
      <Scrollable
        enabled={props.scrollable}
        refreshControl={props.refreshControl}
      >
        <View
          style={{
            paddingBottom: props.renderTopSection ? Layout.padding.large : 0,
          }}
        >
          {props.renderTopSection?.()}
        </View>
        <View style={styles.contentContainer}>
          {props.scrollableContent ? (
            <ScrollView
              showsVerticalScrollIndicator={false}
              style={[styles.contentScrollStyle, props.contentScrollStyle]}
              contentContainerStyle={{ paddingVertical: Layout.padding.xLarge }}
            >
              {props.children}
            </ScrollView>
          ) : (
            props.children
          )}
        </View>
      </Scrollable>
    </ScreenContainer>
  );
}

// PropTypes.oneOf([true, false, undefined])
Screen.propTypes = {
  renderTopSection: PropTypes.func,
  headerProps: ScreenHeader.propTypes,
  title: PropTypes.string,
  contentScrollStyle: ViewPropTypes.style,
  scrollableContent: PropTypes.oneOf([true, false, undefined]),
  scrollable: PropTypes.oneOf([true, false, undefined]),
  loading: PropTypes.oneOf([true, false, undefined]),
  error: PropTypes.string,
  onErrorPress: PropTypes.func,
};

Screen.defaultProps = {
  headerProps: {},
  title: "",
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: Colors.primaryColor,
  },
  contentContainer: {
    flex: 1,
    backgroundColor: Colors.white,
    borderTopLeftRadius: Layout.radius.xxxLarge,
    borderTopRightRadius: Layout.radius.xxxLarge,
  },
  contentScrollStyle: {
    borderTopLeftRadius: Layout.radius.xxxLarge,
    borderTopRightRadius: Layout.radius.xxxLarge,
  },
});
