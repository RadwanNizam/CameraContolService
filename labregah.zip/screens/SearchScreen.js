import React, { useRef, useState, useEffect } from "react";
import {
  StyleSheet,
  TextInput,
  View,
  FlatList,
  ActivityIndicator,
  Keyboard,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import ScreenHeader from "../components/ScreenHeader";
import { Colors, Fonts, Layout, SCREEN_KEYS } from "../constants";
import { t } from "../services/i18n";
import { useFetch, Provider } from "use-http";
import StyledText from "../components/StyledText";
import DataSource from "../constants/DataSource";
import { Feather } from "@expo/vector-icons";
import { I18nManager } from "react-native";
import { getPost } from "../utils/PostLoader";
import { decode } from "html-entities";
import { getAuthToken } from "../utils/Security";
import { handleFetchErrors } from "../utils/FetchData";

function SearchScreen({ route, navigation }) {
  const [value, setValue] = useState("");
  const page = useRef(1);
  const [lastPageReached, setLastPageReached] = useState(false);
  const [data, setData] = useState([]);

  const { get, response, loading, error, abort } = useFetch(
    DataSource.production,
    {
      interceptors: {
        request: async ({ options }) => {
          options.headers.Authorization = await getAuthToken()
          return options;
        },
      },
    }
  );
  const inputRef = useRef();
  const search = async () => {
    try {
      if (value && value.trim().length > 2) {
        setData([]);
        const newData = await get(
          `/search?subtype=news,video,program&search=${value.trim()}&page=${1}`
        );
        if (!response.ok) {
          throw { code: response.status, ...newData };
        }
        setData(newData);
      } else {
        setData([]);
      }
    } catch (error) {
      handleFetchErrors(error);
    }
  };
  const onEndReached = async () => {
    try {
      if (data.length && !lastPageReached && !loading) {
        const newData = await get(
          `/search?subtype=news,video,program&search=${value.trim()}&page=${
            page.current + 1
          }`
        );
        if (!response.ok) {
          throw { code: response.status, ...newData };
        }
        setLastPageReached(!newData.length);
        setData((curr) => [...curr, ...newData]);
        page.current += 1;
      }
    } catch (error) {
      handleFetchErrors(error);
    }
  };

  useEffect(() => {
    page.current = 1;
    setLastPageReached(false);
    search();
    return abort;
  }, [value]);

  const keyExtractor = ({ id }) => id.toString();
  const renderItem = ({ item }) => {
    const onPress = async () => {
      try {
        const post = await getPost(item);
        switch (item.subtype) {
          case "program":
          case "video":
            navigation.navigate(SCREEN_KEYS.VIDEO, { post });
            break;
          case "news":
            navigation.navigate(SCREEN_KEYS.NEWS_POST, { post });
            break;
        }
      } catch (error) {
        handleFetchErrors(error);
      }
    };
    return (
      <>
        <StyledText
          touchable
          style={{ padding: Layout.padding.small }}
          onPress={onPress}
          color={Colors.gray}
          size={Fonts.size.normal}
          children={decode(item.title)}
        />
        <View style={styles.line} />
      </>
    );
  };
  const Loader = () => {
    return <ActivityIndicator color={Colors.primaryColor} />;
  };
  const Empty = () => {
    return loading ? (
      <Loader />
    ) : (
      <StyledText
        center
        color={Colors.gray}
        children={error ? error.message : t("common:noResult")}
      />
    );
  };
  const Footer = () => {
    return loading && data.length ? <Loader /> : null;
  };
  return (
    <SafeAreaView style={styles.container}>
      <ScreenHeader title={t("SearchScreen:title")} color={Colors.gray} />
      <View style={styles.inputContainer}>
        <Feather name="search" size={20} color="black" />
        <TextInput
          ref={inputRef}
          style={styles.input}
          returnKeyType={"done"}
          placeholder={t("SearchScreen:search")}
          onSubmitEditing={Keyboard.dismiss}
          blurOnSubmit={true}
          value={value}
          onChangeText={setValue}
        />
      </View>
      <View style={{ flex: 1 }}>
        <FlatList
          data={data}
          contentContainerStyle={styles.listContainer}
          keyExtractor={keyExtractor}
          onEndReached={onEndReached}
          renderItem={renderItem}
          ListEmptyComponent={<Empty />}
          ListFooterComponent={<Footer />}
        />
      </View>
    </SafeAreaView>
  );
}

export const screenOptions = ({ navigation }) => ({});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  listContainer: {
    paddingHorizontal: Layout.padding.content,
    paddingVertical: Layout.padding.normal,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: Layout.padding.normal,
    borderWidth: 1,
    height: 46,
    borderRadius: Layout.radius.round,
    marginHorizontal: Layout.margin.content,
    borderColor: Colors.lightGray,
  },
  input: {
    flex: 1,
    fontFamily: Fonts.type.regular,
    fontSize: Fonts.size.normal,
    paddingHorizontal: Layout.padding.normal,
    textAlign: I18nManager.isRTL ? "right" : "left",
  },
  line: {
    height: 1,
    backgroundColor: Colors.lightGray,
  },
});

export default SearchScreen;
