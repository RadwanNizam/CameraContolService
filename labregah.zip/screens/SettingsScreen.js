import React from 'react';
import {View, Text, StyleSheet} from 'react-native';


function SettingsScreen ({ route, navigation }) {
    return (    
        <View><Text>Settings Screen</Text></View>    
    )
};

export const screenOptions = ({ navigation }) => ({    
    title: 'Settings Screen'
});


const styles = StyleSheet.create({
    screen:{
    }
});

export default SettingsScreen;