import * as React from "react";
import { Auth } from "aws-amplify";
import { ActivityIndicator, StyleSheet, View, Text } from "react-native";
import { Colors, SCREEN_KEYS } from "../constants";
import useAppContext from "../hooks/useAppContext";

export default function SplashScreen(props) {
  const context = useAppContext();
  React.useEffect(() => {
    Auth.currentAuthenticatedUser()
      .then((user) => {
        if (!!user) {
          context.setIsLogged(true);
        } else {
          props.navigation.replace(SCREEN_KEYS.LOGIN);
        }
      })
      .catch(() => props.navigation.replace(SCREEN_KEYS.LOGIN));
  }, []);
  return (
    <View style={styles.container}>
      <ActivityIndicator color={Colors.white} />     
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primaryColor,
    alignItems: "center",
    justifyContent: "center",
  },
});
