import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  StyleSheet,
  View,
  Text,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import { Colors, Fonts, Layout, SCREEN_KEYS } from "../constants";
import TextButton from "../components/TextButton";
import { Auth } from "aws-amplify";
import StyledText from "../components/StyledText";
import useCountdown from "../hooks/useCountdown";
import {
  CodeField,
  Cursor,
  useBlurOnFulfill,
  useClearByFocusCell,
} from "react-native-confirmation-code-field";
import Toast from "react-native-toast-message";
import useAppContext from "../hooks/useAppContext";
import storeNotificationToken from "../utils/Notifications";

const CELL_COUNT = 6;
const CELL_SIZE =
  (Layout.window.width - Layout.padding.large * 2) / (CELL_COUNT + 1);
export default function VerifyCodeScreen(props) {
  const context = useAppContext();
  const [loading, setLoading] = useState(false);
  const { countdown, reset } = useCountdown(30);
  const [user, setUser] = useState(props.route?.params?.user ?? {});
  const { username: number } = user ?? {};
  const [code, setCode] = useState("");
  const ref = useBlurOnFulfill({ value: code, cellCount: CELL_COUNT });
  const [inputProps, getCellOnLayoutHandler] = useClearByFocusCell({
    value: code,
    setValue: setCode,
  });
  const sendVefificationCode = () => {
    try {
      reset();
      Auth.signIn(number).then((_user) => {
        setUser(_user);
      });
    } catch (error) {}
  };

  const onConfirmPress = () => {
    if (loading || code.length != CELL_COUNT) return;

    setLoading(true);
    Auth.sendCustomChallengeAnswer(user, code)
      .then((result) => {
        if (!result.signInUserSession) {
          return Toast.show({
            text1: "الرقم خاطئ",
            text2: "قم بالتحقق من الرقم المدخل",
            position: "bottom",
            type: "error",
          });
        }
        context.setIsLogged(true);
        storeNotificationToken();
      })
      .catch((error) => {
        if (error?.code == "NotAuthorizedException") {
          setCode("");
          Toast.show({
            text1: "انتهت صلاحية الرقم",
            text2: "سوف نقوم بأرسال رقم جديد للتأكيد",
            position: "bottom",
            type: "info",
          });
          return sendVefificationCode();
        }
        Toast.show({
          text1: "فشل التحقق",
          text2: "قم بالمحاولة مرة اخرى",
          position: "bottom",
          type: "error",
        });
      })
      .finally(() => {
        setLoading(false);
      });
  };
  const onEndEditing = () => {
    if (loading || code.length != CELL_COUNT) return;
    onConfirmPress();
  };
  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={"padding"}
        enabled={Layout.isIOS}
      >
        <View style={styles.container}>
          <StyledText
            center
            children={"لقد تم ارسال رقم التحقق الى جوالك المسجل"}
            bold
            size={Fonts.size.title}
          />
          <StyledText
            center
            style={styles.subtitle}
            children={
              "الرجاء إدخال الرقم المرسد الى جوالك والمكون من ستة ارقام ليتم التحقق من رقم جوالك واستكمال عملية التسجيل"
            }
          />
          <CodeField
            ref={ref}
            {...inputProps}
            value={code}
            onChangeText={setCode}
            cellCount={CELL_COUNT}
            rootStyle={styles.codeFieldRoot}
            keyboardType="number-pad"
            textContentType="oneTimeCode"
            onEndEditing={onEndEditing}
            renderCell={({ index, symbol, isFocused }) => (
              <Text
                key={index}
                style={[styles.cell, isFocused && styles.focusCell]}
                onLayout={getCellOnLayoutHandler(index)}
              >
                {symbol || (isFocused ? <Cursor /> : null)}
              </Text>
            )}
          />
          {countdown ? (
            <StyledText
              style={[styles.resendButton, { opacity: 0.7 }]}
              children={"اعادة ارسال بعد" + " " + countdown}
            />
          ) : (
            <StyledText
              touchable
              style={styles.resendButton}
              children={"اعادة ارسال الرقم"}
              onPress={sendVefificationCode}
            />
          )}

          <TextButton
            isLoading={loading}
            children={"تأكيد"}
            onPress={onConfirmPress}
          />
        </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: Colors.primaryColor,
    padding: Layout.padding.large,
  },
  subtitle: {
    marginTop: Layout.margin.small,
    marginBottom: Layout.margin.xLarge,
    paddingHorizontal: "10%",
  },
  loginButton: {
    marginBottom: Layout.margin.normal,
    marginTop: Layout.margin.large,
  },
  createAccountContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  codeFieldRoot: { width: "100%", flexDirection: Layout.leftDirection },
  cell: {
    width: CELL_SIZE,
    height: CELL_SIZE,
    lineHeight: CELL_SIZE - 2,
    fontSize: 24,
    borderWidth: 1,
    borderRadius: Layout.radius.large,
    color: Colors.white,
    borderColor: "rgba(255, 255, 255, 0.6)",
    textAlign: "center",
  },
  focusCell: {
    borderColor: "#FFFFFF",
  },
  resendButton: {
    padding: Layout.padding.small,
    marginTop: Layout.margin.normal,
    marginBottom: Layout.margin.small,
  },
});
