import React, { useEffect, useRef, useState } from 'react';
import { POSTS } from '../data/data'
import { t, isRTL } from '../services/i18n';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  PixelRatio,
  Dimensions,
  Platform,
  Image,
  Share
} from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';


import Colors from '../constants/Colors';
import VideoPaper from '../components/videos-screen/VideoPaper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { FlatList } from 'react-native-gesture-handler';
import VideosLoader from '../utils/VideosLoader';
import { ActivityIndicator } from 'react-native';
import Screen from "./Screen";
import {decode} from 'html-entities';
/**
 * This screen plays a youtube video, it accepts the following params in the route:
 * route.params.relatedVideos :  The list of videos to be shown under the video (optional)
 * route.params.videoURL : The url to load more videos (optional)
 * route.params.post : of this format {postURL, title, videoURL, youtubeVideoId} (required)
 */
function VideoScreen({ route, navigation }) {

  const windowWidth = Dimensions.get('window').width;

  const [post, setPost] = useState(route.params.post);
  const playerRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [latestVideos, setLatestVideos] = useState(route.params.relatedVideos ? route.params.relatedVideos : [] );
  // const [latestVideos, setLatestVideos] = useState();
  const [loading, setLoading] = useState(true);
  const [pageNumber, setPageNumber] = useState(1);
  const [error, setError] = useState();

  const setLoadingHelper = (loading) => {
    setLoading(loading)
  }
  const setPageNumberHelper = (pageNumber) => {
    setPageNumber(pageNumber)
  }
  const setLatestVideosHelper = (latestVideos) => {
    setLatestVideos(latestVideos)
  }


  let videoURL = route.params && route.params.videoURL ? route.params.videoURL : null;

  let videosLoader = videoURL && videoURL != null ? new VideosLoader(videoURL, setLoadingHelper, pageNumber,
    setPageNumberHelper, latestVideos, setLatestVideosHelper, setError) : null;

  const shareVideo = async () => {
    try {
      const result = await Share.share({
        message: decode(post.postURL) + ' ' + post.title,
        title: 'share this video',
        url: post.videoURL
      });

      if (result.action === Share.sharedAction) {
      
      } else if (result.action === Share.dismissedAction) {
        alert("فشلت عملية المشاركة")
      }
    } catch (error) {
      alert(error.message);
    }
  };

  useEffect(() => {
    if (latestVideos.length === 0 && videosLoader != null) {
      videosLoader.fetchVideos(false);
    }
  }, []);

  const onEndReached = () => {
    return videosLoader.fetchVideos(false)
  }


  const renderItem = ({ item }) => {
    return <TouchableOpacity
      onPress={() => { setPost(item) }}>
      <VideoPaper style={styles.videoPaper} video={item} />
    </TouchableOpacity>
  };


  const renderFooter = () => {
    if (loading) {
      return (
        <View style={{ flex: 1, padding: 24 }}><ActivityIndicator color={Colors.primaryColor} /></View>
      )
    }
    else {
      return <View />;
    }
  };


  const renderTopSection = () => {
    return (
      <View>
        <YoutubePlayer
          ref={playerRef}
          height={windowWidth * 9 / 16}
          width="100%"
          videoId={post.youtubeVideoId != null ? post.youtubeVideoId : ""}
          play={playing}
          // onChangeState={event => console.log(event)}
          // onReady={() => console.log("ready")}
          // onError={e => console.log(e)}
          onPlaybackQualityChange={q => console.log(q)}
          volume={50}
          playbackRate={1}
          playerParams={{
            cc_lang_pref: "us",
            showClosedCaptions: true
          }}
        />

        <View>
          <Text style={styles.videoTitle}>{post.title}</Text>
          <View style={{ flex: 1, flexDirection: 'row-reverse', paddingBottom: 10, paddingStart: 25 }}>
            <View>
              <TouchableOpacity style={styles.shareBtn} onPress={shareVideo}>
                <Image source={require('../assets/share.png')} />
              </TouchableOpacity>
              <Text>مشاركة</Text>
            </View>
          </View>
        </View>
      </View>
    );
  };

  return (


    <Screen
      headerProps={{ live: false, search: true }}
      title={t('VideoScreen:video')}
      renderTopSection={renderTopSection}
      scrollableContent={false}

    >
      <View >
        <View >
          <FlatList
            data={latestVideos}
            renderItem={(item) => renderItem(item)}
            numColumns={1}
            keyExtractor={(post, index) => String(index)}
            scrollEnabled={true}
            showsVerticalScrollIndicator={false}
            ListFooterComponent={renderFooter}
            onEndReached={onEndReached}
            refreshing={loading}
          />
        </View>
      </View>
    </Screen>

  );
};

export const screenOptions = ({ navigation }) => ({
  headerShown: false,
});


const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: 'center',
    // width: '100%',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    // paddingStart: 10,
    // paddingEnd: 10,
    paddingTop: 10,
    backgroundColor: Colors.primaryColor
  },
  screeHeader: {
    borderWidth: 0,
    paddingStart: 0,
    paddingEnd: 0,
    width: Dimensions.get('window').width,
    // height: '100%', 
    flex: 1,
    alignItems: 'stretch',
    backgroundColor: Colors.primaryColor
  },
  area1: {
    alignItems: 'center',
    width: '100%',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
  },

  area2: {
    alignItems: 'center',
    width: '100%',
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    borderTopStartRadius: 40,
    borderTopEndRadius: 40,
    backgroundColor: Colors.secondaryColor
  },

  areaHeader: {
    // flexDirection: "row",
    justifyContent: 'space-between',
    // alignItems: "flex-start",
    width: '100%',
    paddingTop: 5,
    paddingBottom: 5,
    // paddingStart: 15,
    // paddingEnd:15
    // borderColor: 'red',
    // borderWidth: 3


  },
  videoTitle: {
    paddingStart: 15,
    paddingTop: 15,
    fontFamily: "cairo-bold",
    fontSize: 16,
    fontWeight: "normal",
    fontStyle: "normal",
    lineHeight: 23,
    letterSpacing: 0,
    textAlign: "left",

    color: Colors.fontColor1,
    textShadowColor: "black",
    textShadowOffset: {
      width: 0,
      height: 2
    },
    textShadowRadius: 4
  },


  areaBody: {
    width: '100%',

  },
  emptyArea: {
    width: '100%',
    height: 30,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  labregahProgramImage: {

    aspectRatio: 2 / 1,
    borderRadius: 20

  }, videoPaper: {
    width: '100%',
    paddingStart: 15,
    paddingEnd: 15
  }
});

export default VideoScreen;