import React, { useEffect, useState } from 'react';
import { View, FlatList, Text, Button, StyleSheet, ActivityIndicator, Dimensions, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import GenericPost from '../components/GenericPost';
import Colors from '../constants/Colors';
import DataSource from '../constants/DataSource';
import { t, } from '../services/i18n';
import Screen from "./Screen";
import VideosLoader from '../utils/VideosLoader';
import useRefresh from '../hooks/useRefresh';

/**
 * 
 * @param route.params.initialVideos The default list of videos for rendering 
 * @param route.params.videoURL The videos URL provider
 * @param route.params.loadMore If false, then the user can't load more videos
 * @param route.params.loadMoreURLInVideoWindow The url to load more videos after navigating to Video window
 */
function VideosScreen({ route, navigation }) {

  let initialVideos = route.params && route.params.initialVideos ? route.params.initialVideos : [];
  let loadMore = route.params && route.params.loadMore ? route.params.loadMore : true;

  const [latestVideos, setLatestVideos] = useState(initialVideos);
  const [loading, setLoading] = useState(true);
  const [pageNumber, setPageNumber] = useState(1);
  const [error, setError] = useState();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const setLoadingHelper = (loading) => {
    setLoading(loading)
    if (!loading) {
      setIsRefreshing(false)
    }
  }
  const setPageNumberHelper = (pageNumber) => {
    setPageNumber(pageNumber)
  }
  const setLatestVideosHelper = (latestVideos) => {
    setLatestVideos(latestVideos)
  }
  let videoURL = route.params && route.params.videoURL ? route.params.videoURL : DataSource.latest_videos_url;
  let videosLoader = new VideosLoader(videoURL, setLoadingHelper, pageNumber,
    setPageNumberHelper, latestVideos, setLatestVideosHelper,   setError);
  const refreshData = () => {
    setPageNumber(1)
    videosLoader.fetchFirstPage();
  };

  const { resetLastRefreshDate } = useRefresh(refreshData);
  const renderFooter = () => {
    if (loading) {
      return (
        <View style={{ flex: 1, padding: 24 }}><ActivityIndicator color={Colors.primaryColor} /></View>
      )
    }
    else {
      return <View />;
    }
  };

  const renderItem = ({ item }) => {
    return <TouchableOpacity
      onPress={() => navigation.navigate('Video', { post: item, videoURL: DataSource.latest_videos_url })}>
      <GenericPost post={item} navigation={navigation} />
    </TouchableOpacity>
  };

  useEffect(() => {
    if (latestVideos.length == 0) {
      try {
        videosLoader.fetchVideos(false);
      } catch (err) {
        setError(err.message);
      }
    }
    resetLastRefreshDate()
  }, []);

  const loadOlderVideos = () => {
    try {
       videosLoader.fetchVideos(false);
    } catch (err) {
      setError(err.message);
    }
  }
  const onRefresh = () => {
    setIsRefreshing(true)
    videosLoader.fetchVideos(true);
  }
  let titleKey = route.params != null && route.params.titleKey ? route.params.titleKey : 'VideosScreen:latestVideos';
  return (
    <Screen
      // loading={loading}
      error={error}
      onErrorPress={loadOlderVideos}
      // scrollableContent
      // renderTopSection={renderTopSection}
      headerProps={{ live: false, search: true, back: false  }}
      title={t(titleKey)}
    >
      {/* latestVideos.length === 0 ?
      <View style={{ flex: 1, padding: 24 }}><ActivityIndicator /></View> :
      <View style={styles.screen}> */}
        <View style={styles.mainContainer}>
          {loadMore ?
            <FlatList
              data={latestVideos}
              renderItem={(item) => renderItem(item)}
              numColumns={1}
              keyExtractor={(post, index) => String(index)}
              scrollEnabled={true}
              showsVerticalScrollIndicator={false}
              ListFooterComponent={renderFooter}
              onEndReached={loadOlderVideos}
              onRefresh={onRefresh}
              refreshing={isRefreshing}
            />
            :
            <FlatList
              data={latestVideos}
              renderItem={(item) => renderItem(item)}
              numColumns={1}
              keyExtractor={(post, index) => String(index)}
              scrollEnabled={true}
              showsVerticalScrollIndicator={false}
            // ListFooterComponent={renderFooter}
            // onEndReached={onEndReached}
            // onEndReachedThreshold={0}
            // refreshing={loading}
            />
          }
        {/* </View>
      </View> */}
      </View>
      </Screen>
  );
};

/**
 * Accepts the following parameters :
 * route.params.titleKey: The key of the title in the I18n resource files.
 */

export const screenOptions = ({ navigation, route}) => ({

  //       headerTitle: () => {
  //       let titleKey = route.params != null && route.params.titleKey ? route.params.titleKey : 'VideosScreen:latestVideos';
  //   return <SafeAreaView style={{ backgroundColor: "red" }}>
  //       <View width={Dimensions.get('window').width * 80 / 100} style={{ display: 'flex', flexDirection: "row", justifyContent: "space-between", backgroundColor: "red" }}>
  //         <Image source={require('../assets/search.png')} />
  //         <Text style={styles.screenTitle}>{t(titleKey)}</Text>
  //         {/* <Image source={require('../assets/back.png')} /> */}
  //         <Text style={styles.screenTitle}></Text>
  //       </View>
  //     </SafeAreaView>
  // }
  headerShown: false,
});

const styles = StyleSheet.create({
        screen: {
        flex: 1,
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    paddingTop: 10,
    backgroundColor: Colors.primaryColor
  }, mainContainer: {
        alignItems: 'center',
    width: '100%',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    borderTopStartRadius: 30,
    borderTopEndRadius: 30,
    backgroundColor: Colors.secondaryColor,
    flex: 1,
    flexDirection: "column",
    paddingStart: 10,
    paddingEnd: 10,
    paddingTop: 10
  },
  screenTitle: {
        fontFamily: "cairo-bold",
    fontSize: 21,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0,
    color: Colors.fontColor1
  },
  footer: {
        padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  loadMoreBtn: {
        padding: 10,
    backgroundColor: '#800000',
    borderRadius: 4,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnText: {
        color: 'white',
    fontSize: 15,
    textAlign: 'center',
  },
});

export default VideosScreen;