import DataSource from "../../constants/DataSource";
import { wpVideoToAppVideo, wpArticleToAppNewsPost } from "../../utils/WPPostConverter";
import { getAuthToken } from "../../utils/Security"
import FetchData, { handleFetchErrors } from '../../utils/FetchData'
export const FETCH_LATEST_NEWS = 'FETCH_LATEST_NEWS';
export const FETCH_LATEST_VIDEOS = 'FETCH_LATEST_VIDEOS';
export const FETCH_LATEST_PROGRAMS = 'FETCH_LATEST_PROGRAMS';

export const PROGRAM_WINNERS = 'winners';
export const PROGRAM_EZPATY = 'ezpaty';
export const PROGRAM_YARDS = 'yards';
export const PROGRAM_STARS = 'stars';

export const fetchLatestNews = () => {
    return async dispatch => {
        // any async code you want!
        try {
            let authToken = await getAuthToken();

            const response = await fetch(
                DataSource.home_page_news_url
                , {
                    method: 'GET',
                    headers: new Headers({
                        'Authorization': authToken,
                        'AppVersion':FetchData.AppVersion
                    })
                }
            );

            if (!response.ok) {
                throw {code: response.status, ...(await response.json())}
            }

            const resData = await response.json();

            let news = [];
            resData.map((newsPost) => {
                let post = wpArticleToAppNewsPost(newsPost);
                news.push(post)
            });

            dispatch({ type: FETCH_LATEST_NEWS, latestNews: news });
        } catch (err) {
            // send to custom analytics server
            console.log('err', err);
            handleFetchErrors(err)
        }
    };

};

export const fetchLatestVideos = () => {
    return async dispatch => {
        // any async code you want!
        try {
            let authToken = await getAuthToken();

            const response = await fetch(DataSource.home_videos_url
                , {
                    method: 'GET',
                    headers: new Headers({
                        'Authorization': authToken,
                        'AppVersion':FetchData.AppVersion
                    })
                }
            );

            if (!response.ok) {
                throw {code: response.status, ...(await response.json())}
            }

            const resData = await response.json();

            let videos = [];
            resData.map((video) => {
                let appVideo = wpVideoToAppVideo(video);
                videos.push(appVideo);
            });
            dispatch({ type: FETCH_LATEST_VIDEOS, latestVideos: videos });
        } catch (err) {
            // send to custom analytics server
            console.log('err', err);
            handleFetchErrors(err)
        }
    };

};


export const fetchLatestPrograms = () => {
    return async dispatch => {
        // any async code you want!
        try {
            let ezpatyProgram = await fetchPosts(DataSource.latest_program_ezpaty_url,
                'FETCH_LATEST_PROGRAMS_EZPATY_ERROR', PROGRAM_EZPATY);
            let winnersProgram = await fetchPosts(DataSource.latest_program_winners_url,
                'FETCH_LATEST_PROGRAMS_WINNERS_ERROR', PROGRAM_WINNERS);
            let labregahYardProgram = await fetchPosts(DataSource.latest_program_labregah_yeard_url,
                'FETCH_LATEST_PROGRAMS_LABREGAH_YEARD_ERROR', PROGRAM_YARDS);
            let starsProgram = await fetchPosts(DataSource.latest_program_stars_url,
                'FETCH_LATEST_PROGRAMS_STARS_ERROR', PROGRAM_STARS);

            let programs = [];
            if (ezpatyProgram.length > 0) {
                programs.push(ezpatyProgram[0]);
            } else {
                programs.push({});
            }
            if (winnersProgram.length > 0) {
                programs.push(winnersProgram[0]);
            } else {
                programs.push({});
            }
            if (labregahYardProgram.length > 0) {
                programs.push(labregahYardProgram[0]);
            } else {
                programs.push({});
            }
            if (starsProgram.length > 0) {
                programs.push(starsProgram[0]);
            } else {
                programs.push({});
            }
            dispatch({ type: FETCH_LATEST_PROGRAMS, latestPrograms: programs });
        } catch (err) {
            // send to custom analytics server
            console.log('err', err);
            handleFetchErrors(err)
        }
    };
};

async function fetchPosts(url, notOkErrorMsg, postType) {
    let authToken = await getAuthToken();
    const response = await fetch(url
        , {
            method: 'GET',
            headers: new Headers({
                'Authorization': authToken,
                'AppVersion':FetchData.AppVersion
            })
        }
    );


    if (!response.ok) {
        throw {code: response.status, ...(await response.json())}
    }

    const resData = await response.json();
    let videos = [];
    resData.map((video) => {
        let appVideo = wpVideoToAppVideo(video);
        appVideo.postType = postType;
        videos.push(appVideo);
    });

    return videos;
}