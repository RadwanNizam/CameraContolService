import DataSource from "../../constants/DataSource";
import FetchData, { fetchInfo, handleFetchErrors } from '../../utils/FetchData'
import { wpArticleToAppNewsPost } from "../../utils/WPPostConverter";
import { getAuthToken } from "../../utils/Security"

export const FETCH_RACING_DATES_COUNTRIES = 'FETCH_RACING_DATES_COUNTRIES';
export const FETCH_RACING_DATES_SEASONS = 'FETCH_RACING_DATES_SEASONS';
export const FETCH_RACING_DATES_FESTIVALS = 'FETCH_RACING_DATES_FESTIVALS';
export const SEARCH_RACING_DATES = 'SEARCH_RACING_DATES';
export const FETCH_RACE_DATES = 'FETCH_RACE_DATES'
export const CLEAR_RACING_DATES_RESULT = 'CLEAR_RACING_DATES_RESULT'
export const CLEAR_RACING_DATES_SEASONS = 'CLEAR_RACING_DATES_SEASONS'
export const CLEAR_RACING_DATES_FESTIVALS = 'CLEAR_RACING_DATES_FESTIVALS'
export const CLEAR_RACING_DATES_COUNTRIES = 'CLEAR_RACING_DATES_COUNTRIES'

export const fetchCountries = () => {
    return async dispatch => {
        try {
            let countriesResult = await fetchInfo(DataSource.racing_dates_countries_url,
                FETCH_RACING_DATES_COUNTRIES, (country) => { return { id: country.countryId, name: country.name, count: country.racesCount } });

            dispatch({ type: FETCH_RACING_DATES_FESTIVALS, festivals: [] });
            dispatch({ type: FETCH_RACING_DATES_SEASONS, seasons: [] });
            dispatch({ type: FETCH_RACING_DATES_COUNTRIES, countries: countriesResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const fetchSeasons = (countryId) => {
    return async dispatch => {
        try {
            let url = DataSource.racing_dates_seasons_url + '?countryId=' + countryId;
            let seasonsResult = await fetchInfo(url,
                FETCH_RACING_DATES_SEASONS,
                (season) => { return { id: season.seasonId, name: season.name, count: season.racesCount } });
            dispatch({ type: FETCH_RACING_DATES_FESTIVALS, festivals: [] });
            dispatch({ type: FETCH_RACING_DATES_SEASONS, seasons: seasonsResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const fetchFestivals = (countryId, seasonId) => {
    return async dispatch => {
        try {
            let festivalsResult = await fetchInfo(DataSource.racing_dates_festivals_url + '?countryId=' + countryId + '&seasonId=' + seasonId,
                FETCH_RACING_DATES_FESTIVALS,
                (festival) => { return { id: festival.festivalId, name: festival.name, count: festival.racesCount } });
            dispatch({ type: FETCH_RACING_DATES_FESTIVALS, festivals: festivalsResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const searchRacingDates = (countryId, seasonId, festivalId) => {
    return async dispatch => {

        try {
            let authToken = await getAuthToken();
            let url = DataSource.search_racing_dates_url + '?country=' + countryId + '&season=' + seasonId;
            if (festivalId) {
                url += '&festival=' + festivalId;
            }
            const response = await fetch(url, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': authToken,
                    'AppVersion':FetchData.AppVersion
                })
            }
            );
            if (!response.ok) {
                throw {code: response.status, ...(await response.json())}
            }

            const resData = await response.json();
            let races = [];
            resData.map((raceDatePost) => {
                // races.push({ id: race.id, title: race.title.rendered, url: race.country, season: race.season, festival: race.festival});
                let post = wpArticleToAppNewsPost(raceDatePost);

                post.season = raceDatePost.season;
                post.festival = raceDatePost.festival;
                post.country = raceDatePost.country;

                races.push(post);
            });

            dispatch({ type: SEARCH_RACING_DATES, searchResult: races });
        } catch (err) {
            console.log('err', err);
            handleFetchErrors(err)
        }
    };

};

export const clearResults = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_DATES_RESULT });
    };
};
export const clearCountries = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_DATES_COUNTRIES });
    };
}
export const clearSeasons = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_DATES_SEASONS });
    };
}
export const clearFestivals = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_DATES_FESTIVALS });
    };
}