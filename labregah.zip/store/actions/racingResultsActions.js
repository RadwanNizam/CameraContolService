import DataSource from "../../constants/DataSource";
import FetchData, { fetchInfo, handleFetchErrors } from '../../utils/FetchData'
import { getAuthToken } from "../../utils/Security"

export const FETCH_RACING_RESULTS_COUNTRIES = 'FETCH_RACING_RESULTS_COUNTRIES';
export const FETCH_RACING_RESULTS_SEASONS = 'FETCH_RACING_RESULTS_SEASONS';
export const FETCH_RACING_RESULTS_FESTIVALS = 'FETCH_RACING_RESULTS_FESTIVALS';
export const SEARCH_RACING_RESULTS = 'SEARCH_RACING_RESULTS';
export const FETCH_RACE_RESULTS = 'FETCH_RACE_RESULTS'
export const CLEAR_RACING_RESULTS_RESULT = 'CLEAR_RACING_RESULTS_RESULT'
export const CLEAR_RACING_RESULTS_SEASONS = 'CLEAR_RACING_RESULTS_SEASONS'
export const CLEAR_RACING_RESULTS_FESTIVALS = 'CLEAR_RACING_RESULTS_FESTIVALS'
export const CLEAR_RACING_RESULTS_COUNTRIES = 'CLEAR_RACING_RESULTS_COUNTRIES'

export const fetchCountries = () => {
    return async dispatch => {
        try {
            let countriesResult = await fetchInfo(DataSource.racing_results_countries_url,
                FETCH_RACING_RESULTS_COUNTRIES, (country) => { return { id: country.countryId, name: country.name, count: country.racesCount } });
            dispatch({ type: FETCH_RACING_RESULTS_FESTIVALS, festivals: [] });
            dispatch({ type: FETCH_RACING_RESULTS_SEASONS, seasons: [] });
            dispatch({ type: FETCH_RACING_RESULTS_COUNTRIES, countries: countriesResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const fetchSeasons = (countryId) => {
    return async dispatch => {
        try {
            let url = DataSource.racing_results_seasons_url + '?countryId=' + countryId;
            let seasonsResult = await fetchInfo(url,
                FETCH_RACING_RESULTS_SEASONS,
                (season) => { return { id: season.seasonId, name: season.name, count: season.racesCount } });
            dispatch({ type: FETCH_RACING_RESULTS_FESTIVALS, festivals: [] });
            dispatch({ type: FETCH_RACING_RESULTS_SEASONS, seasons: seasonsResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const fetchFestivals = (countryId, seasonId) => {
    return async dispatch => {
        try {
            let festivalsResult = await fetchInfo(DataSource.racing_results_festivals_url + '?countryId=' + countryId + '&seasonId=' + seasonId,
                FETCH_RACING_RESULTS_FESTIVALS,
                (festival) => { return { id: festival.festivalId, name: festival.name, count: festival.racesCount } });
            dispatch({ type: FETCH_RACING_RESULTS_FESTIVALS, festivals: festivalsResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const searchRacingResults = (countryId, seasonId, festivalId) => {
    return async dispatch => {

        try {
            let authToken = await getAuthToken();
            let url = DataSource.search_racing_results_url + '?country=' + countryId + '&season=' + seasonId;
            if (festivalId) {
                url += '&festival=' + festivalId;
            }

            const response = await fetch(url, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': authToken,
                    'AppVersion':FetchData.AppVersion
                })
            }
            );
            if (!response.ok) {
                throw {code: response.status, ...(await response.json())}
            }

            const resData = await response.json();
            let races = [];
            resData.map((race) => {
                races.push({ id: race.id, title: race.title.rendered, country: race.country, season: race.season, 
                    festival: race.festival, from: race.date_from, to: race.date_to });
            });

            dispatch({ type: SEARCH_RACING_RESULTS, searchResult: races });
        } catch (err) {
            handleFetchErrors(err)
        }
    };

};

export const fetchRaceResults = (id) => {
    return async dispatch => {
        try {
            let authToken = await getAuthToken();
            let url = DataSource.fetch_race_results + '?postId=' + id;
            const response = await fetch(url, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': authToken,
                    'AppVersion':FetchData.AppVersion
                })
            }
            );
            if (!response.ok) {
                throw {code: response.status, ...(await response.json())}
            }
            const resData = await response.json();
            dispatch({ type: FETCH_RACE_RESULTS, results: resData.map((item, index) => ({ ...item, index })) });
        } catch (err) {
            handleFetchErrors(err)
        }
    };

};
export const clearResults = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_RESULTS_RESULT });
    };
};
export const clearCountries = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_RESULTS_COUNTRIES });
    };
}
export const clearSeasons = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_RESULTS_SEASONS });
    };
}
export const clearFestivals = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_RESULTS_FESTIVALS });
    };
}