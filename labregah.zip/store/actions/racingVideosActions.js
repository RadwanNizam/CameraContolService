import DataSource from "../../constants/DataSource";
import { getYoutubeVideoId } from "../../utils/VideosLoader";
import FetchData, { fetchInfo, handleFetchErrors } from '../../utils/FetchData'
import { getAuthToken } from "../../utils/Security"

export const FETCH_RACING_VIDEOS_COUNTRIES = 'FETCH_RACING_VIDEOS_COUNTRIES';
export const FETCH_RACING_VIDEOS_SEASONS = 'FETCH_RACING_VIDEOS_SEASONS';
export const FETCH_RACING_VIDEOS_FESTIVALS = 'FETCH_RACING_VIDEOS_FESTIVALS';
export const SEARCH_RACING_VIDEOS = 'SEARCH_RACING_VIDEOS';
export const FETCH_RACE_VIDEOS = 'FETCH_RACE_VIDEOS';
export const CLEAR_RACING_VIDEOS_RESULT = 'CLEAR_RACING_VIDEOS_RESULT';
export const CLEAR_RACING_VIDEOS_SEASONS = 'CLEAR_RACING_VIDEOS_SEASONS';
export const CLEAR_RACING_VIDEOS_FESTIVALS = 'CLEAR_RACING_VIDEOS_FESTIVALS';
export const CLEAR_RACING_VIDEOS_COUNTRIES = 'CLEAR_RACING_VIDEOS_COUNTRIES';

export const fetchCountries = () => {
    return async dispatch => {
        try {
            let countriesResult = await fetchInfo(DataSource.racing_videos_countries_url,
                FETCH_RACING_VIDEOS_COUNTRIES, (country) => { return { id: country.countryId, name: country.name, count: country.racesCount } });
            dispatch({ type: FETCH_RACING_VIDEOS_FESTIVALS, festivals: [] });
            dispatch({ type: FETCH_RACING_VIDEOS_SEASONS, seasons: [] });
            dispatch({ type: FETCH_RACING_VIDEOS_COUNTRIES, countries: countriesResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const fetchSeasons = (countryId) => {
    return async dispatch => {
        try {
            let url = DataSource.racing_videos_seasons_url + '?countryId=' + countryId;
            let seasonsResult = await fetchInfo(url,
                FETCH_RACING_VIDEOS_SEASONS,
                (season) => { return { id: season.seasonId, name: season.name, count: season.racesCount } });
            dispatch({ type: FETCH_RACING_VIDEOS_FESTIVALS, festivals: [] });
            dispatch({ type: FETCH_RACING_VIDEOS_SEASONS, seasons: seasonsResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const fetchFestivals = (countryId, seasonId) => {
    return async dispatch => {
        try {
            let festivalsResult = await fetchInfo(DataSource.racing_videos_festivals_url + '?countryId=' + countryId + '&seasonId=' + seasonId,
                FETCH_RACING_VIDEOS_FESTIVALS,
                (festival) => { return { id: festival.festivalId, name: festival.name, count: festival.racesCount } });
            dispatch({ type: FETCH_RACING_VIDEOS_FESTIVALS, festivals: festivalsResult });
        } catch (err) {
            handleFetchErrors(err)
        }
    };
};

export const searchRacingVideos = (countryId, seasonId, festivalId) => {
    return async dispatch => {
        try {
            let authToken = await getAuthToken();
            let url = DataSource.search_racing_videos_url + '?country=' + countryId + '&season=' + seasonId;
            if (festivalId) {
                url += '&festival=' + festivalId;
            }
            const response = await fetch(url, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': authToken,
                    'AppVersion':FetchData.AppVersion
                })
            }
            );
            if (!response.ok) {
                throw {code: response.status, ...(await response.json())}
            }

            const resData = await response.json();
            let races = [];
            resData.map((race) => {
                races.push({ id: race.id, title: race.title.rendered, country: race.country, season: race.season, 
                    festival: race.festival, from: race.date_from, to: race.date_to });
            });

            dispatch({ type: SEARCH_RACING_VIDEOS, searchResult: races });
        } catch (err) {
            console.log('err', err);
            handleFetchErrors(err)
        }
    };

};

export const fetchRaceVideos = (id) => {
    return async dispatch => {
        try {
            let authToken = await getAuthToken();
            let url = DataSource.fetch_race_videos + '?postId=' + id;
            const response = await fetch(url, {
                method: 'GET',
                headers: new Headers({
                    'Authorization': authToken,
                    'AppVersion':FetchData.AppVersion
                })
            }
            );
            if (!response.ok) {
                throw {code: response.status, ...(await response.json())}
            }
            const resData = await response.json();
            const videos = resData.map((item, index) => {
                item.index = index.toString();
                // let videoId = getYoutubeVideoId(item["youtubePostId"]);
                //   item.youtubeVideoId = item.youtubeVideoId;

                // return item.hasOwnProperty("video_title") ? {
                //     "عنوان_الفيديو": item.video_title,
                //     "الفيديو": item.video,                    
                //     old_response: true,
                //     youtubeVideoId : item.youtubeVideoId
                // } : item;
                return item;

            })
            dispatch({ type: FETCH_RACE_VIDEOS, videos });
        } catch (err) {
            handleFetchErrors(err)
        }
    };

};
export const clearVideos = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_VIDEOS_RESULT });
    };
};
export const clearCountries = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_VIDEOS_COUNTRIES });
    };
}
export const clearSeasons = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_VIDEOS_SEASONS });
    };
}
export const clearFestivals = () => {
    return async dispatch => {
        dispatch({ type: CLEAR_RACING_VIDEOS_FESTIVALS });
    };
}