import {
    latestNews, FETCH_LATEST_NEWS,
    latestVideos, FETCH_LATEST_VIDEOS,
    latestPrograms, FETCH_LATEST_PROGRAMS
} from '../actions/homeActions';

const initialState = {
    latestVideos: [],
    latestNews: [],
    latestPrograms: [{ featuredImgUrl: '' }, { featuredImgUrl: '' }, { featuredImgUrl: '' }]
}
const homeReducer = (state = initialState, action) => {
    switch (action.type) {
        case FETCH_LATEST_NEWS:
            return { ...state, latestNews: action.latestNews };
        case FETCH_LATEST_VIDEOS:
            return { ...state, latestVideos: action.latestVideos };
        case FETCH_LATEST_PROGRAMS:
            return { ...state, latestPrograms: action.latestPrograms };
        default:
            return state; // This case is reached when the app starts and the store is initialized 
    }
    return state;
}

export default homeReducer;
