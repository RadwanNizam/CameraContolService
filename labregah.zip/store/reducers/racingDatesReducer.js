import {
    FETCH_RACING_DATES_COUNTRIES,
    FETCH_RACING_DATES_SEASONS,
    FETCH_RACING_DATES_FESTIVALS,
    SEARCH_RACING_DATES,
    FETCH_RACE_DATES,
    CLEAR_RACING_DATES_RESULT,
    CLEAR_RACING_DATES_SEASONS,
    CLEAR_RACING_DATES_FESTIVALS,
    CLEAR_RACING_DATES_COUNTRIES
} from '../actions/racingDatesActions';

const initialState = {
    countries: [],
    seasons: [],
    festivals: [],
    searchResult:[],
    raceDates: []
}
const racingDatesReducer = (state = initialState, action) => {

    switch (action.type) {
        case FETCH_RACING_DATES_COUNTRIES:
            return { ...state, countries: action.countries };
        case FETCH_RACING_DATES_SEASONS:
            return { ...state, seasons: action.seasons };
        case FETCH_RACING_DATES_FESTIVALS:
            return { ...state, festivals: action.festivals };
        case SEARCH_RACING_DATES:
            return { ...state, searchResult: action.searchResult };       
        case FETCH_RACE_DATES:
            return  { ...state, raceDate: action.results }; 
        case CLEAR_RACING_DATES_RESULT:
            return {...state, searchResult: []}   
        case CLEAR_RACING_DATES_COUNTRIES:
            return {...state, countries: []} 
        case CLEAR_RACING_DATES_SEASONS:
            return {...state, seasons: []}
        case CLEAR_RACING_DATES_FESTIVALS:
            return {...state, festivals: []}
        default:
            return state;
    }

    return state;
}

export default racingDatesReducer;
