import {
    FETCH_RACING_RESULTS_COUNTRIES,
    FETCH_RACING_RESULTS_SEASONS,
    FETCH_RACING_RESULTS_FESTIVALS,
    SEARCH_RACING_RESULTS,
    FETCH_RACE_RESULTS,
    CLEAR_RACING_RESULTS_RESULT,
    CLEAR_RACING_RESULTS_SEASONS,
    CLEAR_RACING_RESULTS_FESTIVALS,
    CLEAR_RACING_RESULTS_COUNTRIES
} from '../actions/racingResultsActions';

const initialState = {
    countries: [],
    seasons: [],
    festivals: [],
    searchResult:[],
    raceResults: []
}
const racingResultsReducer = (state = initialState, action) => {

    switch (action.type) {
        case FETCH_RACING_RESULTS_COUNTRIES:
            return { ...state, countries: action.countries };
        case FETCH_RACING_RESULTS_SEASONS:
            return { ...state, seasons: action.seasons };
        case FETCH_RACING_RESULTS_FESTIVALS:
            return { ...state, festivals: action.festivals };
        case SEARCH_RACING_RESULTS:
            return { ...state, searchResult: action.searchResult };       
        case FETCH_RACE_RESULTS:
            return  { ...state, raceResults: action.results }; 
        case CLEAR_RACING_RESULTS_RESULT:
            return {...state, searchResult: []}  
        case CLEAR_RACING_RESULTS_COUNTRIES:
            return {...state, countries: []} 
        case CLEAR_RACING_RESULTS_SEASONS:
                return {...state, seasons: []}
        case CLEAR_RACING_RESULTS_FESTIVALS:
                return {...state, festivals: []}
        default:
            return state; // This case is reached when the app starts and the store is initialized 
    }

    return state;
}

export default racingResultsReducer;
