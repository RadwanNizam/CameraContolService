import {
    FETCH_RACING_VIDEOS_COUNTRIES,
    FETCH_RACING_VIDEOS_SEASONS,
    FETCH_RACING_VIDEOS_FESTIVALS,
    SEARCH_RACING_VIDEOS,
    FETCH_RACE_VIDEOS,
    CLEAR_RACING_VIDEOS_RESULT,
    CLEAR_RACING_VIDEOS_SEASONS,
    CLEAR_RACING_VIDEOS_FESTIVALS,
    CLEAR_RACING_VIDEOS_COUNTRIES
} from '../actions/racingVideosActions';

const initialState = {
    countries: [],
    seasons: [],
    festivals: [],
    searchResult:[],
    raceVideos: []
}
const racingVideosReducer = (state = initialState, action) => {

    switch (action.type) {
        case FETCH_RACING_VIDEOS_COUNTRIES:
            return { ...state, countries: action.countries };
        case FETCH_RACING_VIDEOS_SEASONS:
            return { ...state, seasons: action.seasons };
        case FETCH_RACING_VIDEOS_FESTIVALS:
            return { ...state, festivals: action.festivals };
        case SEARCH_RACING_VIDEOS:
            return { ...state, searchResult: action.searchResult };     
        case FETCH_RACE_VIDEOS:
            return  { ...state, raceVideos: action.videos };
        case CLEAR_RACING_VIDEOS_RESULT:
            return {...state, searchResult: []}
        case CLEAR_RACING_VIDEOS_COUNTRIES:
            return {...state, countries: []} 
        case CLEAR_RACING_VIDEOS_SEASONS:
                return {...state, seasons: []}
        case CLEAR_RACING_VIDEOS_FESTIVALS:
                return {...state, festivals: []}
        default:
            return state; // This case is reached when the app starts and the store is initialized 
    }

    return state;
}

export default racingVideosReducer;
