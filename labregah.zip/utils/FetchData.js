import { getAuthToken } from "./Security";
import Toast from "react-native-toast-message";
import { t } from "../services/i18n";
import updateAppNotice from "../helpers/updateAppNotice";
import Constants from 'expo-constants';

export default{
  AppVersion : Constants.manifest.version
}

/**
 * Fetch posts from the server and convert them to JSON objects using the provided mapper
 * @param {*} url
 * @param {*} notOkErrorMsg
 * @param {*} mapper
 */
export async function fetchInfo(url, notOkErrorMsg, mapper) {
  let authToken = await getAuthToken();
  const response = await fetch(url, {
    method: "GET",
    headers: new Headers({
      Authorization: authToken,
    }),
  });
  if (!response.ok) {
    throw { message: await response.text(), code: response.status };
  }

  const resData = await response.json();
  let items = [];
  resData.map((item) => {
    items.push(mapper(item));
  });

  return items;
}

export function handleFetchErrors(error = {}) {
  const message = t("codes:" + error.code) ?? error.message;
  switch (error.code) {
    case 426:
      updateAppNotice();
      break;
    default:
      Toast.show({
        position: "bottom",
        type: "error",
        text1: t("common:error"),
        text2: message,
      });
      break;
  }
}
