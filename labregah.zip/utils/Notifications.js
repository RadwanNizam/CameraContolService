import * as Notifications from "expo-notifications";
import * as Permissions from "expo-permissions";
import DataSource from "../constants/DataSource";
import { Auth } from "aws-amplify";
import { getAuthToken } from "../utils/Security";


export async function registerForPushNotificationsAsync() {
  let token;
  const { status: existingStatus } = await Permissions.getAsync(
    Permissions.NOTIFICATIONS
  );
  let finalStatus = existingStatus;
  if (existingStatus !== "granted") {
    const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
    finalStatus = status;
  }
  if (finalStatus !== "granted") {
    // alert("Failed to get push token for push notification!");
    return;
  }
  token = (await Notifications.getExpoPushTokenAsync()).data;

  if (Platform.OS === "android") {
    Notifications.setNotificationChannelAsync("default", {
      name: "default",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#FF231F7C",
    });
  }

  return token;
}


export default async function storeNotificationToken() {
  try {
    const notificationToken = await registerForPushNotificationsAsync();
    const {
      attributes: { sub: userId },
    } = await Auth.currentAuthenticatedUser();
    if (!!notificationToken && !!userId) {
      const authToken = await getAuthToken();
      const result = await fetch(DataSource.store_notification_token, {
        method: 'POST',
        headers: new Headers({
          'Authorization': authToken,
          'Content-Type': 'application/json'
        }),
        body: JSON.stringify({
          notificationToken:notificationToken,
          userId:userId,
        }),
      }).then((res) => res.json());
      //.then((json) => console.log(JSON.stringify(json)));
    }
  } catch (error) {
    console.log("storeNotificationToken: ", error);
  }
}