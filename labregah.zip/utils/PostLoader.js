import DataSource,{VIDEO_URL_QUERY_PARAMS, NEWS_POST_URL_QUERY_PARAMS, PROGRAM_URL_QUERY_PARAMS} from "../constants/DataSource";
import { wpVideoToAppVideo,wpArticleToAppNewsPost } from "./WPPostConverter";
import {decode} from 'html-entities';
import {getAuthToken} from "./Security";
export const POST_SUB_TYPE_VIDEO = 'video';
export const POST_SUB_TYPE_PROGRAM = 'program';
export const POST_SUB_TYPE_NEWS_POST = 'news';

/**
 * Retreives a post from the server using its subtype and id.
 * @param {*} postInfo a JSON object contains the subtype of the post and the id 
 */
export async function getPost(postInfo){
    let post = null;
    let url = null;
    let video = false;
 
    if (postInfo.subtype === POST_SUB_TYPE_VIDEO){
        url = DataSource.video_post_url + postInfo.id + '?' + VIDEO_URL_QUERY_PARAMS;
        video = true;
    }else if (postInfo.subtype === POST_SUB_TYPE_PROGRAM){
        url = DataSource.program_url + postInfo.id + '?' + PROGRAM_URL_QUERY_PARAMS;
        video = true;
    }else if (postInfo.subtype === POST_SUB_TYPE_NEWS_POST){
        url = DataSource.news_post_url + postInfo.id + '?' + NEWS_POST_URL_QUERY_PARAMS;
        video = false;
    }

    let authToken = await getAuthToken();
    let json = await fetch(url, {
        method: 'GET',
        headers: new Headers({
          'Authorization': authToken
        })}).
    then(res => res.json());

    if (video){
        post = wpVideoToAppVideo(json);
    }else{
        post = wpArticleToAppNewsPost(json);
    }

    return post;
}