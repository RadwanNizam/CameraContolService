import {PROGRAM_WINNERS, PROGRAM_YARDS, PROGRAM_EZPATY,PROGRAM_STARS} from '../store/actions/homeActions';
import DataSource from '../constants/DataSource';

/**
 * Returns a URL to load more posts of a Labregah program.
 * @param {} postType The program type 
 */
export function getLoadMoreURL(programName){
    let loadMoreVideoURL = null;

    if (programName == PROGRAM_EZPATY){
        loadMoreVideoURL = DataSource.latest_program_ezpaty_url;
      }else if (programName == PROGRAM_WINNERS){
        loadMoreVideoURL = DataSource.latest_program_winners_url;
      }else if (programName == PROGRAM_YARDS){
        loadMoreVideoURL = DataSource.latest_program_labregah_yeard_url;
      }else if (programName == PROGRAM_STARS){
        loadMoreVideoURL = DataSource.latest_program_stars_url;
      }    
   return loadMoreVideoURL;   
}

/**
 * Returns the first post, from programs, which has the same program name passed in the parameter programName
 * @param {} programName The required program name
 * @param {*} programs Array of programs
 */
export function getLabregahProgram(programName, programs){
    let post = programs.find(program => programName == program.postType);
    return post;
}