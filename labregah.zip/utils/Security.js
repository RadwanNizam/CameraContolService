
import { Auth } from "aws-amplify";

export async function getAuthToken(){
    return (await Auth.currentSession()).getIdToken().getJwtToken();
}
