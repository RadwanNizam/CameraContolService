import { wpVideoToAppVideo } from '../utils/WPPostConverter';
import moment from 'moment';
import {getAuthToken} from "../utils/Security"

export default class VideosLoader {

  constructor(videoURL, setLoadingHelper, pageNumber, setPageNumber, videos, setVideos, setError) {
    this.url = videoURL;
    this.setLoading = setLoadingHelper;
    this.pageNumber = pageNumber;
    this.setPageNumber = setPageNumber;
    this.videos = videos;
    this.setVideos = setVideos;
    this.setError = setError;
  }


  /**
   * @param fetchLatest : If true, the method fetch the latest news (published after the first element in the array 'videos'). 
   * if false, fetches the news before the last element in the array 'videos'.
   */
  fetchVideos = (fetchLatest) => {
    let url = this.url;
    let originalMomentLocale = moment.locale();
    moment.locale('en');
    let resultAppendMode = 0;

    if (fetchLatest) {
      let firstVideoDate = this.videos.length > 0 ? this.videos[0].date : null;
      url += (firstVideoDate != null ? '?after=' + moment(firstVideoDate).format("yyyy-MM-DDTHH:mm:ss") : '');
      resultAppendMode = 1;
    } else {
      let lastVideoDate = this.videos.length > 0 ? this.videos[this.videos.length - 1].date : null;
      url += (lastVideoDate != null ? '?before=' + moment(lastVideoDate).format("yyyy-MM-DDTHH:mm:ss") : '');
      resultAppendMode = 2;
    }

    moment.locale(originalMomentLocale);

    this.fetchPage(url, resultAppendMode);
    
  }

 /**
 * @param fetchLatest : If true, the method fetch the latest news (published after the first element in the array 'news'). 
 * if false, fetches the news before the last element in the array 'news'.
 */
  fetchFirstPage = () => {
    let url = this.url;
    this.fetchPage(url, 0);
  }

  /**
   * Load more videos using the provided URL and append the result to the array videos according to resultAppendMode
   * @param {*} url The URL to load videos
   * @param {*} resultAppendMode  
   *  0 clear previous results and return the retreived videos only
   *  1 add the results to the top of the array videos
   *  2 add the results to the end of the array videos
   */
  async fetchPage (url, resultAppendMode){
    let authToken = await getAuthToken();
    this.setLoading(true);
    fetch(url, {
      method: 'GET',
      headers: new Headers({
        'Authorization': authToken
      })
    }
    )
      .then((response) => response.json())
      .then((json) => {
        if (Array.isArray(json) && json.length > 0) {
          let latest = [];
          json.map((video) => {
            
            // let youtubeURL = getYoutubeVideoURLFromWPPost(video);
            // let postURL = getWordPressPostURL(video);
            // var videoId = getYoutubeVideoId(youtubeURL);
            // latest.push({ id: video.id, featuredImgUrl: video._embedded['wp:featuredmedia']['0'].source_url, title: video.title.rendered, url: youtubeURL, postURL: postURL, youtubeVideoId: videoId })
            latest.push(wpVideoToAppVideo(video));
          }
          );
          
          if (resultAppendMode == 0){
            this.setVideos(latest);
          }else if (resultAppendMode == 1){
            this.setVideos([...latest, ...this.videos]);
          }else{
            this.setVideos([...this.videos, ...latest]);
          }          
        }
        this.setLoading(false);

      })
      .catch((error) => {
        this.setError(error.message);
        handleFetchErrors(error)
      }
      )
      .finally(() => { this.setLoading(false) });
  }
}
