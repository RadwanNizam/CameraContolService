
import {decode} from 'html-entities';

/**
 * Converts a Wordpress Video post to a JSON object for the mobile app 
 */
export function wpVideoToAppVideo(wpVideo){
    let youtubeURL = getYoutubeVideoURLFromWPPost(wpVideo);
    let postURL = getWordPressPostURL(wpVideo);
    var videoId = getYoutubeVideoId(youtubeURL);
    
    let video = { id: wpVideo.id, 
        featuredImgUrl: wpVideo._embedded['wp:featuredmedia']['0'].source_url, 
        title: decode(wpVideo.title.rendered), 
        url: youtubeURL, 
        postURL: postURL, 
        youtubeVideoId:videoId,
        date:wpVideo.date};

        return video;
}

/**
 * Converts a Ninja table record (race video) a JSON object for the mobile app 
 */
export function ninjaTableRecordToAppVideo(ninjaTableRecord){
    let video = { title: ninjaTableRecord["video_title"], url: '', 
        postURL: ninjaTableRecord["video"].permalink, 
        featuredImgUrl: ninjaTableRecord["video"].image_thumb,
        youtubeVideoId:ninjaTableRecord.youtubeVideoId }
    
    return video;
}

export function wpArticleToAppNewsPost(wpArticle){
    let featuredImg = wpArticle._embedded && wpArticle._embedded['wp:featuredmedia'] ? wpArticle._embedded['wp:featuredmedia']['0'].source_url : '';
    return { id: wpArticle.id, featuredImgUrl: featuredImg, 
            title: decode(wpArticle.title.rendered),
            url: wpArticle.guid && wpArticle.guid.rendered ? decode(wpArticle.guid.rendered) : wpArticle.link,
            date:wpArticle.date };
}


export function getYoutubeVideoId(youtubeVideoURL) {
    var regExp = /^.*(youtu.be\/|v\/|e\/|u\/\w+\/|embed\/|v=)([^#\&\?]*).*/;
  
    var match = youtubeVideoURL.match(regExp);
    var videoId = null;
    if (match && match[2].length == 11) {
      videoId = match[2];
  
    }
  
    return videoId;
  }
  
  /**
   * Extracts a youtube video URL from a Word Press post content
   */
  export function getYoutubeVideoURLFromWPPost(video) {
    let videoSrcIndx = video.content.rendered.indexOf('src="');
    let videoSrcEnd = video.content.rendered.indexOf('"', videoSrcIndx + 5);
    let videoURL = video.content.rendered.substring(videoSrcIndx + 5, videoSrcEnd);
    return videoURL;
  }
  
  /**
   * 
   * @param video JSON object represents a Word Press post
   */
  export function getWordPressPostURL(video) {
    let postURL = video.guid.rendered.replace('&#038;', '&'); // If more characters should be encoded then we may consider https://www.npmjs.com/package/html-entities or prepare it at the api gateway
    return postURL;
  }